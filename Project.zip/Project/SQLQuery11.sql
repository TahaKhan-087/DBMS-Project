use imsDB

create table users 
(
usr_id int not null identity primary key,
usr_name varchar(50) not null,
usr_username varchar(50) not null,
usr_password varchar(50) not null,
usr_phone varchar (50) not null,
usr_email varchar (50) not null,
usr_status tinyint not null default 1
)

create procedure st_updateUsers
@name varchar(50),
@username varchar(50),
@pwd nvarchar(50),
@phone varchar(50),
@email varchar(50),
@id int
as
update users
set
usr_name=@name,
usr_username=@username,
usr_password=@pwd,
usr_phone=@phone,
usr_email=@email
where
usr_id=@id


create procedure st_deleteUser
@id int
as
delete from users where usr_id = @id