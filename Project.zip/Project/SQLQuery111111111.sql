create procedure st_getPurchaseInvoiceDetails
@pid bigint
as
select
pid.pid_proID as 'Product ID',
p.pro_name as 'Product',
pid.pid_proquan as 'Quantity',
pid.pid_totprice as 'Total Price',
p.pro_price as 'Per Unit Price'
from purchaseInvoice pii
inner join purchaseInvoiceDetails pid
inner join products p on p.pro_id = pid.pid_proID
on pii.pi_id = pid.pid_purchaseID
where pii.pi_id = @pid