
ALTER procedure st_updateUsers
@name varchar(50),
@username varchar(50),
@pwd nvarchar(50),
@phone varchar(50),
@email varchar(50),
@id int
as
update users
set
usr_name=@name,
usr_username=@username,
usr_password=@pwd,
usr_phone=@phone,
usr_email=@email
where
usr_id=@id