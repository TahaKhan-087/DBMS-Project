create table Employee_infor
(
Name varchar(20) not null,
Age int not null,
ID int primary key,
Salary int,
test int
)

Insert into Employee_infor values('Taha',20,1,9000,2)
Insert into Employee_infor values('Shahrukh',21,2,4000,2)
Insert into Employee_infor values('Shayan',22,3,10000,2)

select* from Employee_infor

alter table Employee_infor drop column test

alter table Employee_infor add DOB date

alter table Employee_infor alter column Name varchar(100)

Select sum(Salary) as 'Total', AVG(salary) as 'Average', min(salary) as 'Min', max(Salary) as 'max' from Employee_infor;
