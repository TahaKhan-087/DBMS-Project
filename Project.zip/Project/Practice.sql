Create table Employee_info
(
EmpID int primary key,
EmpName varchar(20) Not Null,
EmpSalary Decimal (10,2) Not Null,
Job varchar(50),
phone integer unique,
);

INSERT INTO employee_info VALUES(1, 'Haider', 5000, 'Instructor', 11111);
Insert into Employee_info values(2, 'Taha', 10000, 'Head' , 22222);
Insert into Employee_info values(3, 'Shayan', 20000, 'HOD' , 33333);
Insert into Employee_info values(4, 'Sharukh', 21000, 'Principle' , 44444);
Insert into Employee_info values(5, 'Amush', 22000, 'Badmaash' , 55555);
select * from Employee_info;

Update Employee_info SET EmpName = 'Wahaj' where EmpID=2;

DELETE FROM employee_info WHERE empId = 2;

SELECT * FROM Employee_info ORDER BY EmpSalary DESC;

Update Employee_info set EmpSalary=EmpSalary+100 where EmpID=3;

SELECT EmpId AS 'ID', EmpName AS 'Employee', EmpSalary AS 'Salary' FROM employee_info;

SELECT SUM(EmpSalary) AS 'Total Salary', AVG(EmpSalary) AS 'Average Salary', MIN(EmpSalary) AS
'Minimum Salary', MAX(EmpSalary) AS 'Maximum Salary', COUNT(EmpName) AS 'Number of Employees'
FROM Employee_info;

select top 2* from Employee_info;

select pi();
SELECT empName, REPLACE(empName, 'Shayan', 'Ali') FROM employee_info;

SELECT GETDATE();
