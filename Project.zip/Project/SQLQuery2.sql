create table stock
(
st_proID int not null unique,
st_quan int not null
)

create procedure st_insertStock
@proID int,
@quan int
as
insert into stock values (@proID,@quan)

create procedure st_updateStock
@quan int,
@proID int
as
update stock
set st_proID = @proID

create procedure st_getProductQuantity
@proID INT
AS
BEGIN
    SELECT s.st_quan AS 'Quantity'
    FROM stock s
    WHERE s.st_proID = @proID;
END;