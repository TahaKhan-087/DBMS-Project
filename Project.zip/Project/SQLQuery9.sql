use imsDB


Create procedure st_insertUsers
@name varchar(50),
@username varchar(50),
@pwd nvarchar(50),
@phone varchar(50),
@email varchar(50)
as
insert into users (usr_name,usr_username,usr_password,usr_phone,usr_email)
values (@name,@username,@pwd,@phone,@email)