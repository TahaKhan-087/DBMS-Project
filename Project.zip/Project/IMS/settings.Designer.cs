﻿namespace IMS
{
    partial class settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            server_label = new Label();
            serverTxt = new TextBox();
            databaseTxt = new TextBox();
            database_label = new Label();
            userTxt = new TextBox();
            user_label = new Label();
            passTxt = new TextBox();
            pass_label = new Label();
            isCB = new CheckBox();
            saveBtn = new Button();
            LeftPanel.SuspendLayout();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(saveBtn);
            LeftPanel.Controls.Add(isCB);
            LeftPanel.Controls.Add(passTxt);
            LeftPanel.Controls.Add(pass_label);
            LeftPanel.Controls.Add(userTxt);
            LeftPanel.Controls.Add(user_label);
            LeftPanel.Controls.Add(databaseTxt);
            LeftPanel.Controls.Add(database_label);
            LeftPanel.Controls.Add(serverTxt);
            LeftPanel.Controls.Add(server_label);
            LeftPanel.Paint += LeftPanel_Paint;
            LeftPanel.Controls.SetChildIndex(server_label, 0);
            LeftPanel.Controls.SetChildIndex(serverTxt, 0);
            LeftPanel.Controls.SetChildIndex(database_label, 0);
            LeftPanel.Controls.SetChildIndex(databaseTxt, 0);
            LeftPanel.Controls.SetChildIndex(user_label, 0);
            LeftPanel.Controls.SetChildIndex(userTxt, 0);
            LeftPanel.Controls.SetChildIndex(pass_label, 0);
            LeftPanel.Controls.SetChildIndex(passTxt, 0);
            LeftPanel.Controls.SetChildIndex(isCB, 0);
            LeftPanel.Controls.SetChildIndex(saveBtn, 0);
            // 
            // server_label
            // 
            server_label.AutoSize = true;
            server_label.Location = new Point(12, 101);
            server_label.Name = "server_label";
            server_label.Size = new Size(50, 20);
            server_label.TabIndex = 1;
            server_label.Text = "Server";
            // 
            // serverTxt
            // 
            serverTxt.Location = new Point(12, 133);
            serverTxt.MaxLength = 100;
            serverTxt.Name = "serverTxt";
            serverTxt.Size = new Size(209, 27);
            serverTxt.TabIndex = 2;
            // 
            // databaseTxt
            // 
            databaseTxt.Location = new Point(12, 200);
            databaseTxt.MaxLength = 100;
            databaseTxt.Name = "databaseTxt";
            databaseTxt.Size = new Size(209, 27);
            databaseTxt.TabIndex = 4;
            // 
            // database_label
            // 
            database_label.AutoSize = true;
            database_label.Location = new Point(12, 168);
            database_label.Name = "database_label";
            database_label.Size = new Size(72, 20);
            database_label.TabIndex = 3;
            database_label.Text = "Database";
            // 
            // userTxt
            // 
            userTxt.Location = new Point(12, 268);
            userTxt.MaxLength = 100;
            userTxt.Name = "userTxt";
            userTxt.Size = new Size(209, 27);
            userTxt.TabIndex = 6;
            // 
            // user_label
            // 
            user_label.AutoSize = true;
            user_label.Location = new Point(12, 236);
            user_label.Name = "user_label";
            user_label.Size = new Size(57, 20);
            user_label.TabIndex = 5;
            user_label.Text = "User ID";
            // 
            // passTxt
            // 
            passTxt.Location = new Point(12, 335);
            passTxt.MaxLength = 100;
            passTxt.Name = "passTxt";
            passTxt.Size = new Size(209, 27);
            passTxt.TabIndex = 8;
            passTxt.UseSystemPasswordChar = true;
            // 
            // pass_label
            // 
            pass_label.AutoSize = true;
            pass_label.Location = new Point(12, 303);
            pass_label.Name = "pass_label";
            pass_label.Size = new Size(70, 20);
            pass_label.TabIndex = 7;
            pass_label.Text = "Password";
            // 
            // isCB
            // 
            isCB.AutoSize = true;
            isCB.Location = new Point(12, 368);
            isCB.Name = "isCB";
            isCB.Size = new Size(156, 24);
            isCB.TabIndex = 9;
            isCB.Text = "Integrated Security";
            isCB.UseVisualStyleBackColor = true;
            isCB.CheckedChanged += isCB_CheckedChanged;
            // 
            // saveBtn
            // 
            saveBtn.FlatAppearance.BorderSize = 2;
            saveBtn.FlatStyle = FlatStyle.Flat;
            saveBtn.Location = new Point(12, 398);
            saveBtn.Name = "saveBtn";
            saveBtn.Size = new Size(207, 40);
            saveBtn.TabIndex = 10;
            saveBtn.Text = "Save";
            saveBtn.UseVisualStyleBackColor = true;
            saveBtn.Click += saveBtn_Click;
            // 
            // settings
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "settings";
            Text = "settings";
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button saveBtn;
        private CheckBox isCB;
        private TextBox passTxt;
        private Label pass_label;
        private TextBox userTxt;
        private Label user_label;
        private TextBox databaseTxt;
        private Label database_label;
        private TextBox serverTxt;
        private Label server_label;
    }
}