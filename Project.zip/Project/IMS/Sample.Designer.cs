﻿namespace IMS
{
    partial class Sample
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LeftPanel = new Panel();
            panel1 = new Panel();
            label1 = new Label();
            RightPanel = new Panel();
            panel2 = new Panel();
            userLabel = new Label();
            LeftPanel.SuspendLayout();
            panel1.SuspendLayout();
            RightPanel.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.BackColor = Color.FromArgb(64, 64, 64);
            LeftPanel.Controls.Add(panel1);
            LeftPanel.Dock = DockStyle.Left;
            LeftPanel.ForeColor = SystemColors.ControlLightLight;
            LeftPanel.Location = new Point(0, 0);
            LeftPanel.Name = "LeftPanel";
            LeftPanel.Size = new Size(250, 450);
            LeftPanel.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 85);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.Dock = DockStyle.Right;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(66, 0);
            label1.Name = "label1";
            label1.Size = new Size(184, 85);
            label1.TabIndex = 1;
            label1.Text = "Welcome";
            label1.TextAlign = ContentAlignment.MiddleRight;
            label1.Click += label1_Click;
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(panel2);
            RightPanel.Dock = DockStyle.Fill;
            RightPanel.Location = new Point(250, 0);
            RightPanel.Name = "RightPanel";
            RightPanel.Size = new Size(550, 450);
            RightPanel.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.Controls.Add(userLabel);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(550, 85);
            panel2.TabIndex = 1;
            // 
            // userLabel
            // 
            userLabel.Dock = DockStyle.Left;
            userLabel.Font = new Font("Segoe UI", 12F);
            userLabel.Location = new Point(0, 0);
            userLabel.Name = "userLabel";
            userLabel.Size = new Size(477, 85);
            userLabel.TabIndex = 2;
            userLabel.Text = "User";
            userLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Sample
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            ControlBox = false;
            Controls.Add(RightPanel);
            Controls.Add(LeftPanel);
            Name = "Sample";
            LeftPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            RightPanel.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        protected Panel LeftPanel;
        protected Panel RightPanel;
        protected Label label1;
        protected Panel panel1;
        protected Label userLabel;
        protected Panel panel2;
    }
}