﻿namespace IMS
{
    partial class Sample2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel3 = new Panel();
            tableLayoutPanel1 = new TableLayoutPanel();
            DeleteBtn = new Button();
            saveBtn = new Button();
            EditBtn = new Button();
            addBtn = new Button();
            groupBox1 = new GroupBox();
            SearchTxtBox = new TextBox();
            viewBtn = new Button();
            panel4 = new Panel();
            BackBtn = new Button();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(panel4);
            LeftPanel.Controls.SetChildIndex(panel1, 0);
            LeftPanel.Controls.SetChildIndex(panel4, 0);
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(panel3);
            RightPanel.Controls.SetChildIndex(panel2, 0);
            RightPanel.Controls.SetChildIndex(panel3, 0);
            // 
            // panel1
            // 
            panel1.Controls.Add(BackBtn);
            panel1.Controls.SetChildIndex(label1, 0);
            panel1.Controls.SetChildIndex(BackBtn, 0);
            // 
            // panel3
            // 
            panel3.Controls.Add(tableLayoutPanel1);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 85);
            panel3.Name = "panel3";
            panel3.Size = new Size(550, 46);
            panel3.TabIndex = 2;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 6;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.666666F));
            tableLayoutPanel1.Controls.Add(DeleteBtn, 3, 0);
            tableLayoutPanel1.Controls.Add(saveBtn, 2, 0);
            tableLayoutPanel1.Controls.Add(EditBtn, 1, 0);
            tableLayoutPanel1.Controls.Add(addBtn, 0, 0);
            tableLayoutPanel1.Controls.Add(groupBox1, 5, 0);
            tableLayoutPanel1.Controls.Add(viewBtn, 4, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(550, 46);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // DeleteBtn
            // 
            DeleteBtn.Cursor = Cursors.Hand;
            DeleteBtn.Dock = DockStyle.Fill;
            DeleteBtn.FlatAppearance.BorderSize = 2;
            DeleteBtn.FlatStyle = FlatStyle.Flat;
            DeleteBtn.Location = new Point(276, 3);
            DeleteBtn.Name = "DeleteBtn";
            DeleteBtn.Size = new Size(85, 40);
            DeleteBtn.TabIndex = 3;
            DeleteBtn.Text = "DELETE";
            DeleteBtn.UseVisualStyleBackColor = true;
            DeleteBtn.Click += DeleteBtn_Click;
            // 
            // saveBtn
            // 
            saveBtn.Cursor = Cursors.Hand;
            saveBtn.Dock = DockStyle.Fill;
            saveBtn.FlatAppearance.BorderSize = 2;
            saveBtn.FlatStyle = FlatStyle.Flat;
            saveBtn.Location = new Point(185, 3);
            saveBtn.Name = "saveBtn";
            saveBtn.Size = new Size(85, 40);
            saveBtn.TabIndex = 2;
            saveBtn.Text = "SAVE";
            saveBtn.UseVisualStyleBackColor = true;
            saveBtn.Click += saveBtn_Click;
            // 
            // EditBtn
            // 
            EditBtn.Cursor = Cursors.Hand;
            EditBtn.Dock = DockStyle.Fill;
            EditBtn.FlatAppearance.BorderSize = 2;
            EditBtn.FlatStyle = FlatStyle.Flat;
            EditBtn.Location = new Point(94, 3);
            EditBtn.Name = "EditBtn";
            EditBtn.Size = new Size(85, 40);
            EditBtn.TabIndex = 1;
            EditBtn.Text = "EDIT";
            EditBtn.UseVisualStyleBackColor = true;
            EditBtn.Click += EditBtn_Click;
            // 
            // addBtn
            // 
            addBtn.Cursor = Cursors.Hand;
            addBtn.Dock = DockStyle.Fill;
            addBtn.FlatAppearance.BorderSize = 2;
            addBtn.FlatStyle = FlatStyle.Flat;
            addBtn.Location = new Point(3, 3);
            addBtn.Name = "addBtn";
            addBtn.Size = new Size(85, 40);
            addBtn.TabIndex = 0;
            addBtn.Text = "ADD";
            addBtn.UseVisualStyleBackColor = true;
            addBtn.Click += addBtn_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(SearchTxtBox);
            groupBox1.Dock = DockStyle.Fill;
            groupBox1.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(458, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(89, 40);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "SEARCH";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // SearchTxtBox
            // 
            SearchTxtBox.Dock = DockStyle.Fill;
            SearchTxtBox.Location = new Point(3, 21);
            SearchTxtBox.Name = "SearchTxtBox";
            SearchTxtBox.Size = new Size(83, 25);
            SearchTxtBox.TabIndex = 0;
            SearchTxtBox.TextChanged += textBox1_TextChanged;
            // 
            // viewBtn
            // 
            viewBtn.Dock = DockStyle.Fill;
            viewBtn.FlatAppearance.BorderSize = 2;
            viewBtn.FlatStyle = FlatStyle.Flat;
            viewBtn.Location = new Point(367, 3);
            viewBtn.Name = "viewBtn";
            viewBtn.Size = new Size(85, 40);
            viewBtn.TabIndex = 5;
            viewBtn.Text = "VIEW";
            viewBtn.UseVisualStyleBackColor = true;
            viewBtn.Click += viewBtn_Click;
            // 
            // panel4
            // 
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 85);
            panel4.Name = "panel4";
            panel4.Size = new Size(250, 46);
            panel4.TabIndex = 1;
            // 
            // BackBtn
            // 
            BackBtn.Dock = DockStyle.Top;
            BackBtn.FlatAppearance.BorderSize = 2;
            BackBtn.FlatStyle = FlatStyle.Flat;
            BackBtn.Location = new Point(0, 0);
            BackBtn.Name = "BackBtn";
            BackBtn.Size = new Size(66, 29);
            BackBtn.TabIndex = 3;
            BackBtn.Text = "Back";
            BackBtn.UseVisualStyleBackColor = true;
            BackBtn.Click += BackBtn_Click;
            // 
            // Sample2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "Sample2";
            LeftPanel.ResumeLayout(false);
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        public Panel panel3;
        public TableLayoutPanel tableLayoutPanel1;
        public Button DeleteBtn;
        public Button saveBtn;
        public Button EditBtn;
        public Button addBtn;
        public GroupBox groupBox1;
        public Panel panel4;
        public TextBox SearchTxtBox;
        public Button BackBtn;
        public Button viewBtn;
    }
}