﻿namespace IMS
{
    partial class Sales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            dataGridView1 = new DataGridView();
            proIDGV = new DataGridViewTextBoxColumn();
            proGV = new DataGridViewTextBoxColumn();
            quantityGV = new DataGridViewTextBoxColumn();
            pupGV = new DataGridViewTextBoxColumn();
            TotGV = new DataGridViewTextBoxColumn();
            deleteGV = new DataGridViewButtonColumn();
            tableLayoutPanel2 = new TableLayoutPanel();
            grossLabel = new Label();
            label7 = new Label();
            label2 = new Label();
            barcodeTxt = new TextBox();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tableLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // BackBtn
            // 
            BackBtn.FlatAppearance.BorderSize = 2;
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(barcodeTxt);
            LeftPanel.Controls.Add(label2);
            LeftPanel.Controls.SetChildIndex(panel1, 0);
            LeftPanel.Controls.SetChildIndex(panel4, 0);
            LeftPanel.Controls.SetChildIndex(label2, 0);
            LeftPanel.Controls.SetChildIndex(barcodeTxt, 0);
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(tableLayoutPanel2);
            RightPanel.Controls.Add(dataGridView1);
            RightPanel.Controls.SetChildIndex(panel2, 0);
            RightPanel.Controls.SetChildIndex(panel3, 0);
            RightPanel.Controls.SetChildIndex(dataGridView1, 0);
            RightPanel.Controls.SetChildIndex(tableLayoutPanel2, 0);
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { proIDGV, proGV, quantityGV, pupGV, TotGV, deleteGV });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.ControlDark;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.Dock = DockStyle.Top;
            dataGridView1.Location = new Point(0, 131);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(550, 234);
            dataGridView1.TabIndex = 6;
            // 
            // proIDGV
            // 
            proIDGV.HeaderText = "proID";
            proIDGV.MinimumWidth = 6;
            proIDGV.Name = "proIDGV";
            proIDGV.ReadOnly = true;
            proIDGV.Visible = false;
            // 
            // proGV
            // 
            proGV.HeaderText = "Product";
            proGV.MinimumWidth = 6;
            proGV.Name = "proGV";
            proGV.ReadOnly = true;
            // 
            // quantityGV
            // 
            quantityGV.HeaderText = "Quantity";
            quantityGV.MinimumWidth = 6;
            quantityGV.Name = "quantityGV";
            quantityGV.ReadOnly = true;
            // 
            // pupGV
            // 
            pupGV.HeaderText = "per Unit Price";
            pupGV.MinimumWidth = 6;
            pupGV.Name = "pupGV";
            pupGV.ReadOnly = true;
            // 
            // TotGV
            // 
            TotGV.HeaderText = "Total Amount";
            TotGV.MinimumWidth = 6;
            TotGV.Name = "TotGV";
            TotGV.ReadOnly = true;
            // 
            // deleteGV
            // 
            deleteGV.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            deleteGV.HeaderText = "Action";
            deleteGV.MinimumWidth = 6;
            deleteGV.Name = "deleteGV";
            deleteGV.ReadOnly = true;
            deleteGV.Text = "DELETE";
            deleteGV.UseColumnTextForButtonValue = true;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 64.90909F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35.0909081F));
            tableLayoutPanel2.Controls.Add(grossLabel, 0, 0);
            tableLayoutPanel2.Controls.Add(label7, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(0, 365);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(550, 85);
            tableLayoutPanel2.TabIndex = 7;
            // 
            // grossLabel
            // 
            grossLabel.AutoSize = true;
            grossLabel.Dock = DockStyle.Fill;
            grossLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            grossLabel.Location = new Point(360, 0);
            grossLabel.Name = "grossLabel";
            grossLabel.Size = new Size(187, 85);
            grossLabel.TabIndex = 17;
            grossLabel.Text = "0.00";
            grossLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            label7.Dock = DockStyle.Fill;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(3, 0);
            label7.Name = "label7";
            label7.Size = new Size(351, 85);
            label7.TabIndex = 14;
            label7.Text = "Gross Total:";
            label7.TextAlign = ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 134);
            label2.Name = "label2";
            label2.Size = new Size(102, 20);
            label2.TabIndex = 2;
            label2.Text = "Enter Barcode";
            // 
            // barcodeTxt
            // 
            barcodeTxt.Location = new Point(12, 157);
            barcodeTxt.Name = "barcodeTxt";
            barcodeTxt.Size = new Size(232, 27);
            barcodeTxt.TabIndex = 3;
            barcodeTxt.TextChanged += barcodeTxt_TextChanged;
            barcodeTxt.Validating += barcodeTxt_Validating;
            // 
            // Sales
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "Sales";
            Text = "Sales";
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel2;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn proIDGV;
        private DataGridViewTextBoxColumn proGV;
        private DataGridViewTextBoxColumn quantityGV;
        private DataGridViewTextBoxColumn pupGV;
        private DataGridViewTextBoxColumn TotGV;
        private DataGridViewButtonColumn deleteGV;
        private Label label7;
        private Label grossLabel;
        private TextBox barcodeTxt;
        private Label label2;
    }
}