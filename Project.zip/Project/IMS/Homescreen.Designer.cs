﻿namespace IMS
{
    partial class Homescreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            salesBtn = new Button();
            purchaseBtn = new Button();
            stockBtn = new Button();
            productDD = new Button();
            UserBtn = new Button();
            button1 = new Button();
            suppBtn = new Button();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.Size = new Size(250, 521);
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(tableLayoutPanel1);
            RightPanel.Size = new Size(724, 521);
            RightPanel.Controls.SetChildIndex(panel2, 0);
            RightPanel.Controls.SetChildIndex(tableLayoutPanel1, 0);
            // 
            // panel2
            // 
            panel2.Size = new Size(724, 85);
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 5;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.Controls.Add(salesBtn, 4, 0);
            tableLayoutPanel1.Controls.Add(purchaseBtn, 3, 0);
            tableLayoutPanel1.Controls.Add(stockBtn, 2, 0);
            tableLayoutPanel1.Controls.Add(productDD, 1, 0);
            tableLayoutPanel1.Controls.Add(UserBtn, 0, 0);
            tableLayoutPanel1.Controls.Add(button1, 0, 1);
            tableLayoutPanel1.Controls.Add(suppBtn, 1, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 85);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 5;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.Size = new Size(724, 436);
            tableLayoutPanel1.TabIndex = 2;
            // 
            // salesBtn
            // 
            salesBtn.BackColor = SystemColors.ActiveCaption;
            salesBtn.Cursor = Cursors.Hand;
            salesBtn.Dock = DockStyle.Fill;
            salesBtn.FlatAppearance.BorderSize = 2;
            salesBtn.FlatStyle = FlatStyle.Flat;
            salesBtn.ForeColor = SystemColors.ActiveCaptionText;
            salesBtn.Location = new Point(579, 3);
            salesBtn.Name = "salesBtn";
            salesBtn.Size = new Size(142, 81);
            salesBtn.TabIndex = 4;
            salesBtn.Text = "Sales";
            salesBtn.UseVisualStyleBackColor = false;
            salesBtn.Click += salesBtn_Click;
            // 
            // purchaseBtn
            // 
            purchaseBtn.BackColor = SystemColors.ActiveCaption;
            purchaseBtn.Cursor = Cursors.Hand;
            purchaseBtn.Dock = DockStyle.Fill;
            purchaseBtn.FlatAppearance.BorderSize = 2;
            purchaseBtn.FlatStyle = FlatStyle.Flat;
            purchaseBtn.ForeColor = SystemColors.ActiveCaptionText;
            purchaseBtn.Location = new Point(435, 3);
            purchaseBtn.Name = "purchaseBtn";
            purchaseBtn.Size = new Size(138, 81);
            purchaseBtn.TabIndex = 3;
            purchaseBtn.Text = "Purchase Invoice";
            purchaseBtn.UseVisualStyleBackColor = false;
            purchaseBtn.Click += purchaseBtn_Click;
            // 
            // stockBtn
            // 
            stockBtn.BackColor = SystemColors.ActiveCaption;
            stockBtn.Cursor = Cursors.Hand;
            stockBtn.Dock = DockStyle.Fill;
            stockBtn.FlatAppearance.BorderSize = 2;
            stockBtn.FlatStyle = FlatStyle.Flat;
            stockBtn.ForeColor = SystemColors.ActiveCaptionText;
            stockBtn.Location = new Point(291, 3);
            stockBtn.Name = "stockBtn";
            stockBtn.Size = new Size(138, 81);
            stockBtn.TabIndex = 2;
            stockBtn.Text = "Stocks";
            stockBtn.UseVisualStyleBackColor = false;
            stockBtn.Click += stockBtn_Click;
            // 
            // productDD
            // 
            productDD.BackColor = SystemColors.ActiveCaption;
            productDD.Cursor = Cursors.Hand;
            productDD.Dock = DockStyle.Fill;
            productDD.FlatAppearance.BorderSize = 2;
            productDD.FlatStyle = FlatStyle.Flat;
            productDD.ForeColor = SystemColors.ActiveCaptionText;
            productDD.Location = new Point(147, 3);
            productDD.Name = "productDD";
            productDD.Size = new Size(138, 81);
            productDD.TabIndex = 1;
            productDD.Text = "Products";
            productDD.UseVisualStyleBackColor = false;
            productDD.Click += productDD_Click;
            // 
            // UserBtn
            // 
            UserBtn.BackColor = SystemColors.ActiveCaption;
            UserBtn.Cursor = Cursors.Hand;
            UserBtn.Dock = DockStyle.Fill;
            UserBtn.FlatAppearance.BorderSize = 2;
            UserBtn.FlatStyle = FlatStyle.Flat;
            UserBtn.ForeColor = SystemColors.ActiveCaptionText;
            UserBtn.Location = new Point(3, 3);
            UserBtn.Name = "UserBtn";
            UserBtn.Size = new Size(138, 81);
            UserBtn.TabIndex = 0;
            UserBtn.Text = "User";
            UserBtn.TextImageRelation = TextImageRelation.TextBeforeImage;
            UserBtn.UseVisualStyleBackColor = false;
            UserBtn.Click += UserBtn_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ActiveCaption;
            button1.Cursor = Cursors.Hand;
            button1.Dock = DockStyle.Fill;
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(3, 90);
            button1.Name = "button1";
            button1.Size = new Size(138, 81);
            button1.TabIndex = 5;
            button1.Text = "Categories";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // suppBtn
            // 
            suppBtn.BackColor = SystemColors.ActiveCaption;
            suppBtn.Cursor = Cursors.Hand;
            suppBtn.Dock = DockStyle.Fill;
            suppBtn.FlatAppearance.BorderSize = 2;
            suppBtn.FlatStyle = FlatStyle.Flat;
            suppBtn.ForeColor = SystemColors.ActiveCaptionText;
            suppBtn.Location = new Point(147, 90);
            suppBtn.Name = "suppBtn";
            suppBtn.Size = new Size(138, 81);
            suppBtn.TabIndex = 6;
            suppBtn.Text = "Suppliers";
            suppBtn.UseVisualStyleBackColor = false;
            suppBtn.Click += suppBtn_Click;
            // 
            // Homescreen
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(974, 521);
            Name = "Homescreen";
            Text = "Home Screen";
            Load += Homescreen_Load;
            LeftPanel.ResumeLayout(false);
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Button UserBtn;
        private Button salesBtn;
        private Button purchaseBtn;
        private Button stockBtn;
        private Button productDD;
        private Button button1;
        private Button suppBtn;
    }
}