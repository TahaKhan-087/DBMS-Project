﻿namespace IMS
{
    partial class Users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            label3 = new Label();
            NameTxt = new TextBox();
            UsernameTxt = new TextBox();
            label4 = new Label();
            passwordTxt = new TextBox();
            label5 = new Label();
            PhoneTxt = new TextBox();
            label6 = new Label();
            EmailTxt = new TextBox();
            label7 = new Label();
            NameErrorLabel = new Label();
            UsernameErrorLabel = new Label();
            PasswordErrorLabel = new Label();
            PhoneErrorLabel = new Label();
            EmailErrorLabel = new Label();
            dataGridView1 = new DataGridView();
            userIDGV = new DataGridViewTextBoxColumn();
            NameGV = new DataGridViewTextBoxColumn();
            UserNameGV = new DataGridViewTextBoxColumn();
            PassGV = new DataGridViewTextBoxColumn();
            EmailGV = new DataGridViewTextBoxColumn();
            PhoneGV = new DataGridViewTextBoxColumn();
            statusGV = new DataGridViewTextBoxColumn();
            label8 = new Label();
            statusDD = new ComboBox();
            label9 = new Label();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // SearchTxtBox
            // 
            SearchTxtBox.Size = new Size(120, 25);
            SearchTxtBox.TextChanged += SearchTxtBox_TextChanged;
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(label9);
            LeftPanel.Controls.Add(statusDD);
            LeftPanel.Controls.Add(label8);
            LeftPanel.Controls.Add(EmailErrorLabel);
            LeftPanel.Controls.Add(PhoneErrorLabel);
            LeftPanel.Controls.Add(UsernameErrorLabel);
            LeftPanel.Controls.Add(NameErrorLabel);
            LeftPanel.Controls.Add(EmailTxt);
            LeftPanel.Controls.Add(label7);
            LeftPanel.Controls.Add(PhoneTxt);
            LeftPanel.Controls.Add(label6);
            LeftPanel.Controls.Add(passwordTxt);
            LeftPanel.Controls.Add(label5);
            LeftPanel.Controls.Add(UsernameTxt);
            LeftPanel.Controls.Add(label4);
            LeftPanel.Controls.Add(NameTxt);
            LeftPanel.Controls.Add(label3);
            LeftPanel.Controls.Add(PasswordErrorLabel);
            LeftPanel.Size = new Size(250, 528);
            LeftPanel.Controls.SetChildIndex(PasswordErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(panel1, 0);
            LeftPanel.Controls.SetChildIndex(label3, 0);
            LeftPanel.Controls.SetChildIndex(NameTxt, 0);
            LeftPanel.Controls.SetChildIndex(label4, 0);
            LeftPanel.Controls.SetChildIndex(UsernameTxt, 0);
            LeftPanel.Controls.SetChildIndex(label5, 0);
            LeftPanel.Controls.SetChildIndex(passwordTxt, 0);
            LeftPanel.Controls.SetChildIndex(label6, 0);
            LeftPanel.Controls.SetChildIndex(PhoneTxt, 0);
            LeftPanel.Controls.SetChildIndex(label7, 0);
            LeftPanel.Controls.SetChildIndex(EmailTxt, 0);
            LeftPanel.Controls.SetChildIndex(NameErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(UsernameErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(PhoneErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(EmailErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(label8, 0);
            LeftPanel.Controls.SetChildIndex(statusDD, 0);
            LeftPanel.Controls.SetChildIndex(label9, 0);
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(dataGridView1);
            RightPanel.Size = new Size(777, 528);
            RightPanel.Controls.SetChildIndex(panel2, 0);
            RightPanel.Controls.SetChildIndex(dataGridView1, 0);
            // 
            // label1
            // 
            label1.Location = new Point(72, 0);
            label1.Size = new Size(178, 85);
            // 
            // panel1
            // 
            panel1.Location = new Point(0, 46);
            // 
            // panel2
            // 
            panel2.Location = new Point(0, 46);
            panel2.Size = new Size(777, 85);
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 143);
            label3.Name = "label3";
            label3.Size = new Size(49, 20);
            label3.TabIndex = 2;
            label3.Text = "Name";
            // 
            // NameTxt
            // 
            NameTxt.Location = new Point(12, 166);
            NameTxt.MaxLength = 50;
            NameTxt.Name = "NameTxt";
            NameTxt.Size = new Size(216, 27);
            NameTxt.TabIndex = 3;
            // 
            // UsernameTxt
            // 
            UsernameTxt.Location = new Point(12, 229);
            UsernameTxt.MaxLength = 50;
            UsernameTxt.Name = "UsernameTxt";
            UsernameTxt.Size = new Size(216, 27);
            UsernameTxt.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(17, 200);
            label4.Name = "label4";
            label4.Size = new Size(78, 20);
            label4.TabIndex = 4;
            label4.Text = "UserName";
            // 
            // passwordTxt
            // 
            passwordTxt.Location = new Point(12, 282);
            passwordTxt.MaxLength = 50;
            passwordTxt.Name = "passwordTxt";
            passwordTxt.Size = new Size(216, 27);
            passwordTxt.TabIndex = 7;
            passwordTxt.UseSystemPasswordChar = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(17, 259);
            label5.Name = "label5";
            label5.Size = new Size(70, 20);
            label5.TabIndex = 6;
            label5.Text = "Password";
            // 
            // PhoneTxt
            // 
            PhoneTxt.Location = new Point(12, 341);
            PhoneTxt.MaxLength = 50;
            PhoneTxt.Name = "PhoneTxt";
            PhoneTxt.Size = new Size(216, 27);
            PhoneTxt.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(17, 318);
            label6.Name = "label6";
            label6.Size = new Size(167, 20);
            label6.TabIndex = 8;
            label6.Text = "Phone (03XX-XXXXXXX)";
            // 
            // EmailTxt
            // 
            EmailTxt.Location = new Point(12, 399);
            EmailTxt.MaxLength = 50;
            EmailTxt.Name = "EmailTxt";
            EmailTxt.Size = new Size(216, 27);
            EmailTxt.TabIndex = 11;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 376);
            label7.Name = "label7";
            label7.Size = new Size(46, 20);
            label7.TabIndex = 10;
            label7.Text = "Email";
            // 
            // NameErrorLabel
            // 
            NameErrorLabel.AutoSize = true;
            NameErrorLabel.Location = new Point(57, 143);
            NameErrorLabel.Name = "NameErrorLabel";
            NameErrorLabel.Size = new Size(15, 20);
            NameErrorLabel.TabIndex = 12;
            NameErrorLabel.Text = "*";
            NameErrorLabel.Visible = false;
            // 
            // UsernameErrorLabel
            // 
            UsernameErrorLabel.AutoSize = true;
            UsernameErrorLabel.Location = new Point(93, 200);
            UsernameErrorLabel.Name = "UsernameErrorLabel";
            UsernameErrorLabel.Size = new Size(15, 20);
            UsernameErrorLabel.TabIndex = 13;
            UsernameErrorLabel.Text = "*";
            UsernameErrorLabel.Visible = false;
            // 
            // PasswordErrorLabel
            // 
            PasswordErrorLabel.AutoSize = true;
            PasswordErrorLabel.Location = new Point(93, 259);
            PasswordErrorLabel.Name = "PasswordErrorLabel";
            PasswordErrorLabel.Size = new Size(15, 20);
            PasswordErrorLabel.TabIndex = 14;
            PasswordErrorLabel.Text = "*";
            PasswordErrorLabel.Visible = false;
            // 
            // PhoneErrorLabel
            // 
            PhoneErrorLabel.AutoSize = true;
            PhoneErrorLabel.Location = new Point(178, 318);
            PhoneErrorLabel.Name = "PhoneErrorLabel";
            PhoneErrorLabel.Size = new Size(15, 20);
            PhoneErrorLabel.TabIndex = 15;
            PhoneErrorLabel.Text = "*";
            PhoneErrorLabel.Visible = false;
            // 
            // EmailErrorLabel
            // 
            EmailErrorLabel.AutoSize = true;
            EmailErrorLabel.Location = new Point(57, 376);
            EmailErrorLabel.Name = "EmailErrorLabel";
            EmailErrorLabel.Size = new Size(15, 20);
            EmailErrorLabel.TabIndex = 16;
            EmailErrorLabel.Text = "*";
            EmailErrorLabel.Visible = false;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { userIDGV, NameGV, UserNameGV, PassGV, EmailGV, PhoneGV, statusGV });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.ControlDark;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(0, 131);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(777, 397);
            dataGridView1.TabIndex = 3;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // userIDGV
            // 
            userIDGV.HeaderText = "UserID";
            userIDGV.MinimumWidth = 6;
            userIDGV.Name = "userIDGV";
            userIDGV.ReadOnly = true;
            userIDGV.Visible = false;
            // 
            // NameGV
            // 
            NameGV.HeaderText = "Name";
            NameGV.MinimumWidth = 6;
            NameGV.Name = "NameGV";
            NameGV.ReadOnly = true;
            // 
            // UserNameGV
            // 
            UserNameGV.HeaderText = "Username";
            UserNameGV.MinimumWidth = 6;
            UserNameGV.Name = "UserNameGV";
            UserNameGV.ReadOnly = true;
            // 
            // PassGV
            // 
            PassGV.HeaderText = "Password";
            PassGV.MinimumWidth = 6;
            PassGV.Name = "PassGV";
            PassGV.ReadOnly = true;
            PassGV.Visible = false;
            // 
            // EmailGV
            // 
            EmailGV.HeaderText = "Email";
            EmailGV.MinimumWidth = 6;
            EmailGV.Name = "EmailGV";
            EmailGV.ReadOnly = true;
            // 
            // PhoneGV
            // 
            PhoneGV.HeaderText = "Phone #";
            PhoneGV.MinimumWidth = 6;
            PhoneGV.Name = "PhoneGV";
            PhoneGV.ReadOnly = true;
            // 
            // statusGV
            // 
            statusGV.HeaderText = "Status";
            statusGV.MinimumWidth = 6;
            statusGV.Name = "statusGV";
            statusGV.ReadOnly = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(15, 439);
            label8.Name = "label8";
            label8.Size = new Size(49, 20);
            label8.TabIndex = 17;
            label8.Text = "Status";
            // 
            // statusDD
            // 
            statusDD.FormattingEnabled = true;
            statusDD.Items.AddRange(new object[] { "Active", "In-active" });
            statusDD.Location = new Point(12, 462);
            statusDD.Name = "statusDD";
            statusDD.Size = new Size(216, 28);
            statusDD.TabIndex = 18;
            statusDD.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(70, 439);
            label9.Name = "label9";
            label9.Size = new Size(15, 20);
            label9.TabIndex = 19;
            label9.Text = "*";
            label9.Visible = false;
            // 
            // Users
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1027, 528);
            Name = "Users";
            Text = "Users";
            Load += Users_Load;
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TextBox NameTxt;
        private Label label3;
        private TextBox EmailTxt;
        private Label label7;
        private TextBox PhoneTxt;
        private Label label6;
        private TextBox passwordTxt;
        private Label label5;
        private TextBox UsernameTxt;
        private Label label4;
        private Label NameErrorLabel;
        private Label EmailErrorLabel;
        private Label PhoneErrorLabel;
        private Label UsernameErrorLabel;
        private Label PasswordErrorLabel;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn userIDGV;
        private DataGridViewTextBoxColumn NameGV;
        private DataGridViewTextBoxColumn UserNameGV;
        private DataGridViewTextBoxColumn PassGV;
        private DataGridViewTextBoxColumn EmailGV;
        private DataGridViewTextBoxColumn PhoneGV;
        private DataGridViewTextBoxColumn statusGV;
        private ComboBox statusDD;
        private Label label8;
        private Label label9;
    }
}