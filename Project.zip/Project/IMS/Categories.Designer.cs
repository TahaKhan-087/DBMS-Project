﻿namespace IMS
{
    partial class Categories
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            activeErrorLable = new Label();
            label5 = new Label();
            catErrorLabel = new Label();
            catTxt = new TextBox();
            label3 = new Label();
            activeDD = new ComboBox();
            dataGridView1 = new DataGridView();
            catIDGV = new DataGridViewTextBoxColumn();
            NameGV = new DataGridViewTextBoxColumn();
            statusGV = new DataGridViewTextBoxColumn();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(activeDD);
            LeftPanel.Controls.Add(activeErrorLable);
            LeftPanel.Controls.Add(label5);
            LeftPanel.Controls.Add(catErrorLabel);
            LeftPanel.Controls.Add(catTxt);
            LeftPanel.Controls.Add(label3);
            LeftPanel.Controls.SetChildIndex(panel1, 0);
            LeftPanel.Controls.SetChildIndex(label3, 0);
            LeftPanel.Controls.SetChildIndex(catTxt, 0);
            LeftPanel.Controls.SetChildIndex(catErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(label5, 0);
            LeftPanel.Controls.SetChildIndex(activeErrorLable, 0);
            LeftPanel.Controls.SetChildIndex(activeDD, 0);
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(dataGridView1);
            RightPanel.Controls.SetChildIndex(panel2, 0);
            RightPanel.Controls.SetChildIndex(dataGridView1, 0);
            // 
            // panel1
            // 
            panel1.Location = new Point(0, 46);
            // 
            // panel2
            // 
            panel2.Location = new Point(0, 46);
            // 
            // activeErrorLable
            // 
            activeErrorLable.AutoSize = true;
            activeErrorLable.Location = new Point(75, 186);
            activeErrorLable.Name = "activeErrorLable";
            activeErrorLable.Size = new Size(15, 20);
            activeErrorLable.TabIndex = 22;
            activeErrorLable.Text = "*";
            activeErrorLable.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 185);
            label5.Name = "label5";
            label5.Size = new Size(64, 20);
            label5.TabIndex = 20;
            label5.Text = "Is Active";
            // 
            // catErrorLabel
            // 
            catErrorLabel.AutoSize = true;
            catErrorLabel.Location = new Point(122, 132);
            catErrorLabel.Name = "catErrorLabel";
            catErrorLabel.Size = new Size(15, 20);
            catErrorLabel.TabIndex = 19;
            catErrorLabel.Text = "*";
            catErrorLabel.Visible = false;
            // 
            // catTxt
            // 
            catTxt.Location = new Point(8, 155);
            catTxt.Name = "catTxt";
            catTxt.Size = new Size(232, 27);
            catTxt.TabIndex = 18;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 132);
            label3.Name = "label3";
            label3.Size = new Size(113, 20);
            label3.TabIndex = 17;
            label3.Text = "Category Name";
            // 
            // activeDD
            // 
            activeDD.DropDownStyle = ComboBoxStyle.DropDownList;
            activeDD.FormattingEnabled = true;
            activeDD.Items.AddRange(new object[] { "Yes", "No" });
            activeDD.Location = new Point(8, 209);
            activeDD.Name = "activeDD";
            activeDD.Size = new Size(232, 28);
            activeDD.TabIndex = 23;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { catIDGV, NameGV, statusGV });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.ControlDark;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(0, 131);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(550, 319);
            dataGridView1.TabIndex = 4;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // catIDGV
            // 
            catIDGV.HeaderText = "catID";
            catIDGV.MinimumWidth = 6;
            catIDGV.Name = "catIDGV";
            catIDGV.ReadOnly = true;
            catIDGV.Visible = false;
            // 
            // NameGV
            // 
            NameGV.HeaderText = "Name";
            NameGV.MinimumWidth = 6;
            NameGV.Name = "NameGV";
            NameGV.ReadOnly = true;
            // 
            // statusGV
            // 
            statusGV.HeaderText = "Status";
            statusGV.MinimumWidth = 6;
            statusGV.Name = "statusGV";
            statusGV.ReadOnly = true;
            // 
            // Categories
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "Categories";
            Text = "Categories";
            Load += Categories_Load;
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private ComboBox activeDD;
        private Label activeErrorLable;
        private Label label5;
        private Label catErrorLabel;
        private TextBox catTxt;
        private Label label3;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn catIDGV;
        private DataGridViewTextBoxColumn NameGV;
        private DataGridViewTextBoxColumn statusGV;
    }
}