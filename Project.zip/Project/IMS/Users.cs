﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class Users : Sample2
    {
        int edit = 0; // This zero is an indication to the save operation and one is an indication to the Update operation
        int userID;
        short stat;
        public Users()
        {
            InitializeComponent();
        }
        Retrieval r = new Retrieval();
        private void Users_Load(object sender, EventArgs e)
        {
            MainClass.disable_reset(LeftPanel);
        }

        public override void addBtn_Click(object sender, EventArgs e)
        {
            MainClass.enable_reset(LeftPanel);
            edit = 0;
        }

        public override void EditBtn_Click(object sender, EventArgs e)
        {
            edit = 1;
            MainClass.enable(LeftPanel);
        }

        public override void saveBtn_Click(object sender, EventArgs e)
        {
            if (NameTxt.Text == "") { NameErrorLabel.Visible = true; } else { NameErrorLabel.Visible = false; }
            if (UsernameTxt.Text == "") { UsernameErrorLabel.Visible = true; } else { UsernameErrorLabel.Visible = false; }
            if (passwordTxt.Text == "") { passwordTxt.Visible = true; } else { passwordTxt.Visible = false; }
            if (EmailTxt.Text == "") { EmailErrorLabel.Visible = true; } else { EmailErrorLabel.Visible = false; }
            if (PhoneTxt.Text == "") { PhoneErrorLabel.Visible = true; } else { PhoneErrorLabel.Visible = false; }

            if (NameErrorLabel.Visible || UsernameErrorLabel.Visible || PasswordErrorLabel.Visible || EmailErrorLabel.Visible || PhoneErrorLabel.Visible)
            {
                MainClass.ShowMsg("Fields with * are mandatory", "Stop", "Error"); //Error is the type of msg
            }

            else
            {
                if (statusDD.SelectedIndex == 0)
                {
                    stat = 1;
                }
                else if (statusDD.SelectedIndex == 1)
                {
                    stat = 0;
                }

                if (edit == 0) //Code for save operation
                {
                    insertion i = new insertion();
                    i.insertUser(NameTxt.Text, UsernameTxt.Text, passwordTxt.Text, EmailTxt.Text, PhoneTxt.Text, stat);
                    r.showUsers(dataGridView1, userIDGV, NameGV, UserNameGV, PassGV, EmailGV, PhoneGV, statusGV);
                    MainClass.disable_reset(LeftPanel);
                }

                else if (edit == 1) //Code for  Update operation
                {
                    DialogResult dr = MessageBox.Show("Are you sure you want to update record?", "Question...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr == DialogResult.Yes)
                    {
                        Updation u = new Updation();
                        if (statusDD.SelectedIndex == 0)
                        {
                            stat = 1;
                        }
                        else if (statusDD.SelectedIndex == 1)
                        {
                            stat = 0;
                        }
                        u.UpdateUser(userID, NameTxt.Text, UsernameTxt.Text, passwordTxt.Text, EmailTxt.Text, PhoneTxt.Text, stat);
                        r.showUsers(dataGridView1, userIDGV, NameGV, UserNameGV, PassGV, EmailGV, PhoneGV, statusGV);
                        MainClass.disable_reset(LeftPanel);
                    }
                }
            }
        }

        public override void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (edit == 1)
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to delete record?", "Question...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    Deletion d = new Deletion();
                    d.Delete(userID, "st_deleteUser", "@id");
                    r.showUsers(dataGridView1, userIDGV, NameGV, UserNameGV, PassGV, EmailGV, PhoneGV, statusGV);
                }
            }
        }

        public override void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public override void viewBtn_Click(object sender, EventArgs e)
        {
            r.showUsers(dataGridView1, userIDGV, NameGV, UserNameGV, PassGV, EmailGV, PhoneGV, statusGV);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                edit = 1;
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                userID = Convert.ToInt32(row.Cells["userIDGV"].Value.ToString());
                NameTxt.Text = row.Cells["NameGV"].Value.ToString();
                UsernameTxt.Text = row.Cells["UserNameGV"].Value.ToString();
                passwordTxt.Text = row.Cells["PassGV"].Value.ToString();
                PhoneTxt.Text = row.Cells["PhoneGV"].Value.ToString();
                EmailTxt.Text = row.Cells["EmailGV"].Value.ToString();
                statusDD.SelectedItem = row.Cells["statusGV"].Value.ToString();
                MainClass.disable(LeftPanel);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SearchTxtBox_TextChanged(object sender, EventArgs e)
        {
            if (SearchTxtBox.Text!="")
            {
                r.showUsers(dataGridView1, userIDGV, NameGV, UserNameGV, PassGV, EmailGV, PhoneGV, statusGV,SearchTxtBox.Text);
            }
            else
            {
                r.showUsers(dataGridView1, userIDGV, NameGV, UserNameGV, PassGV, EmailGV, PhoneGV, statusGV);
            }
        }
    }
}
