﻿namespace IMS
{
    partial class Supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            supplierCompanyTxt = new Label();
            personNameTxt = new Label();
            ntnTxteqrqwe = new Label();
            NameTxt = new TextBox();
            personTxt = new TextBox();
            phoneTxt = new TextBox();
            addressTxt = new TextBox();
            ntnTxt = new TextBox();
            Status = new Label();
            statusDD = new ComboBox();
            NameErrorLabel = new Label();
            phoneErrorLabel = new Label();
            personErrorLabel = new Label();
            statErrorLabel = new Label();
            addressErrorLabel = new Label();
            label7 = new Label();
            label8 = new Label();
            dataGridView1 = new DataGridView();
            suppIDGV = new DataGridViewTextBoxColumn();
            CompanyGV = new DataGridViewTextBoxColumn();
            personGV = new DataGridViewTextBoxColumn();
            PhoneGV = new DataGridViewTextBoxColumn();
            addressGV = new DataGridViewTextBoxColumn();
            ntnGV = new DataGridViewTextBoxColumn();
            statusGV = new DataGridViewTextBoxColumn();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(label8);
            LeftPanel.Controls.Add(personErrorLabel);
            LeftPanel.Controls.Add(NameErrorLabel);
            LeftPanel.Controls.Add(statusDD);
            LeftPanel.Controls.Add(Status);
            LeftPanel.Controls.Add(ntnTxt);
            LeftPanel.Controls.Add(addressTxt);
            LeftPanel.Controls.Add(phoneTxt);
            LeftPanel.Controls.Add(personTxt);
            LeftPanel.Controls.Add(NameTxt);
            LeftPanel.Controls.Add(ntnTxteqrqwe);
            LeftPanel.Controls.Add(personNameTxt);
            LeftPanel.Controls.Add(supplierCompanyTxt);
            LeftPanel.Controls.Add(phoneErrorLabel);
            LeftPanel.Controls.Add(statErrorLabel);
            LeftPanel.Controls.Add(addressErrorLabel);
            LeftPanel.Controls.Add(label7);
            LeftPanel.Paint += LeftPanel_Paint;
            LeftPanel.Controls.SetChildIndex(label7, 0);
            LeftPanel.Controls.SetChildIndex(addressErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(statErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(phoneErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(panel1, 0);
            LeftPanel.Controls.SetChildIndex(supplierCompanyTxt, 0);
            LeftPanel.Controls.SetChildIndex(personNameTxt, 0);
            LeftPanel.Controls.SetChildIndex(ntnTxteqrqwe, 0);
            LeftPanel.Controls.SetChildIndex(NameTxt, 0);
            LeftPanel.Controls.SetChildIndex(personTxt, 0);
            LeftPanel.Controls.SetChildIndex(phoneTxt, 0);
            LeftPanel.Controls.SetChildIndex(addressTxt, 0);
            LeftPanel.Controls.SetChildIndex(ntnTxt, 0);
            LeftPanel.Controls.SetChildIndex(Status, 0);
            LeftPanel.Controls.SetChildIndex(statusDD, 0);
            LeftPanel.Controls.SetChildIndex(NameErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(personErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(label8, 0);
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(dataGridView1);
            RightPanel.Controls.SetChildIndex(panel2, 0);
            RightPanel.Controls.SetChildIndex(dataGridView1, 0);
            // 
            // panel1
            // 
            panel1.Location = new Point(0, 46);
            // 
            // panel2
            // 
            panel2.Location = new Point(0, 46);
            // 
            // supplierCompanyTxt
            // 
            supplierCompanyTxt.AutoSize = true;
            supplierCompanyTxt.Location = new Point(12, 134);
            supplierCompanyTxt.Name = "supplierCompanyTxt";
            supplierCompanyTxt.Size = new Size(177, 20);
            supplierCompanyTxt.TabIndex = 3;
            supplierCompanyTxt.Text = "Supplier Name/Company";
            // 
            // personNameTxt
            // 
            personNameTxt.AutoSize = true;
            personNameTxt.Location = new Point(12, 186);
            personNameTxt.Name = "personNameTxt";
            personNameTxt.Size = new Size(107, 20);
            personNameTxt.TabIndex = 5;
            personNameTxt.Text = "Contact Person";
            // 
            // ntnTxteqrqwe
            // 
            ntnTxteqrqwe.AutoSize = true;
            ntnTxteqrqwe.Location = new Point(12, 334);
            ntnTxteqrqwe.Name = "ntnTxteqrqwe";
            ntnTxteqrqwe.Size = new Size(48, 20);
            ntnTxteqrqwe.TabIndex = 11;
            ntnTxteqrqwe.Text = "NTN#";
            // 
            // NameTxt
            // 
            NameTxt.Location = new Point(12, 157);
            NameTxt.MaxLength = 100;
            NameTxt.Name = "NameTxt";
            NameTxt.Size = new Size(232, 27);
            NameTxt.TabIndex = 12;
            // 
            // personTxt
            // 
            personTxt.Location = new Point(12, 207);
            personTxt.MaxLength = 50;
            personTxt.Name = "personTxt";
            personTxt.Size = new Size(232, 27);
            personTxt.TabIndex = 13;
            // 
            // phoneTxt
            // 
            phoneTxt.Location = new Point(12, 256);
            phoneTxt.MaxLength = 15;
            phoneTxt.Name = "phoneTxt";
            phoneTxt.Size = new Size(232, 27);
            phoneTxt.TabIndex = 14;
            // 
            // addressTxt
            // 
            addressTxt.Location = new Point(12, 307);
            addressTxt.MaxLength = 100;
            addressTxt.Name = "addressTxt";
            addressTxt.Size = new Size(232, 27);
            addressTxt.TabIndex = 15;
            // 
            // ntnTxt
            // 
            ntnTxt.Location = new Point(12, 357);
            ntnTxt.MaxLength = 25;
            ntnTxt.Name = "ntnTxt";
            ntnTxt.Size = new Size(232, 27);
            ntnTxt.TabIndex = 16;
            // 
            // Status
            // 
            Status.AutoSize = true;
            Status.Location = new Point(14, 387);
            Status.Name = "Status";
            Status.Size = new Size(49, 20);
            Status.TabIndex = 17;
            Status.Text = "Status";
            // 
            // statusDD
            // 
            statusDD.FormattingEnabled = true;
            statusDD.Items.AddRange(new object[] { "Active", "In-active" });
            statusDD.Location = new Point(12, 410);
            statusDD.MaxLength = 100;
            statusDD.Name = "statusDD";
            statusDD.Size = new Size(232, 28);
            statusDD.TabIndex = 18;
            // 
            // NameErrorLabel
            // 
            NameErrorLabel.AutoSize = true;
            NameErrorLabel.Location = new Point(195, 134);
            NameErrorLabel.Name = "NameErrorLabel";
            NameErrorLabel.Size = new Size(15, 20);
            NameErrorLabel.TabIndex = 19;
            NameErrorLabel.Text = "*";
            // 
            // phoneErrorLabel
            // 
            phoneErrorLabel.AutoSize = true;
            phoneErrorLabel.Location = new Point(59, 233);
            phoneErrorLabel.Name = "phoneErrorLabel";
            phoneErrorLabel.Size = new Size(15, 20);
            phoneErrorLabel.TabIndex = 20;
            phoneErrorLabel.Text = "*";
            // 
            // personErrorLabel
            // 
            personErrorLabel.AutoSize = true;
            personErrorLabel.Location = new Point(113, 187);
            personErrorLabel.Name = "personErrorLabel";
            personErrorLabel.Size = new Size(15, 20);
            personErrorLabel.TabIndex = 21;
            personErrorLabel.Text = "*";
            // 
            // statErrorLabel
            // 
            statErrorLabel.AutoSize = true;
            statErrorLabel.Location = new Point(59, 387);
            statErrorLabel.Name = "statErrorLabel";
            statErrorLabel.Size = new Size(15, 20);
            statErrorLabel.TabIndex = 22;
            statErrorLabel.Text = "*";
            // 
            // addressErrorLabel
            // 
            addressErrorLabel.AutoSize = true;
            addressErrorLabel.Location = new Point(80, 284);
            addressErrorLabel.Name = "addressErrorLabel";
            addressErrorLabel.Size = new Size(15, 20);
            addressErrorLabel.TabIndex = 23;
            addressErrorLabel.Text = "*";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 233);
            label7.Name = "label7";
            label7.Size = new Size(50, 20);
            label7.TabIndex = 24;
            label7.Text = "Phone";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(12, 284);
            label8.Name = "label8";
            label8.Size = new Size(62, 20);
            label8.TabIndex = 25;
            label8.Text = "Address";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { suppIDGV, CompanyGV, personGV, PhoneGV, addressGV, ntnGV, statusGV });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.ControlDark;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(0, 131);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(550, 319);
            dataGridView1.TabIndex = 4;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // suppIDGV
            // 
            suppIDGV.HeaderText = "SuppID";
            suppIDGV.MinimumWidth = 6;
            suppIDGV.Name = "suppIDGV";
            suppIDGV.ReadOnly = true;
            suppIDGV.Visible = false;
            // 
            // CompanyGV
            // 
            CompanyGV.HeaderText = "Company";
            CompanyGV.MinimumWidth = 6;
            CompanyGV.Name = "CompanyGV";
            CompanyGV.ReadOnly = true;
            // 
            // personGV
            // 
            personGV.HeaderText = "Contact person";
            personGV.MinimumWidth = 6;
            personGV.Name = "personGV";
            personGV.ReadOnly = true;
            // 
            // PhoneGV
            // 
            PhoneGV.HeaderText = "phone";
            PhoneGV.MinimumWidth = 6;
            PhoneGV.Name = "PhoneGV";
            PhoneGV.ReadOnly = true;
            // 
            // addressGV
            // 
            addressGV.HeaderText = "Address";
            addressGV.MinimumWidth = 6;
            addressGV.Name = "addressGV";
            addressGV.ReadOnly = true;
            // 
            // ntnGV
            // 
            ntnGV.HeaderText = "NTN #";
            ntnGV.MinimumWidth = 6;
            ntnGV.Name = "ntnGV";
            ntnGV.ReadOnly = true;
            // 
            // statusGV
            // 
            statusGV.HeaderText = "Status";
            statusGV.MinimumWidth = 6;
            statusGV.Name = "statusGV";
            statusGV.ReadOnly = true;
            // 
            // Supplier
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "Supplier";
            Text = "Supplier";
            Load += Supplier_Load;
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label supplierCompanyTxt;
        private Button button1;
        private Label statErrorLabel;
        private Button button4;
        private Label personErrorLabel;
        private Button button3;
        private Label personNameTxt;
        private Button button2;
        private Label ntnTxteqrqwe;
        private TextBox ntnTxt;
        private TextBox addressTxt;
        private TextBox phoneTxt;
        private TextBox personTxt;
        private TextBox NameTxt;
        private ComboBox statusDD;
        private Label Status;
        private Label NameErrorLabel;
        private Label phoneErrorLabel;
        private Label addressErrorLabel;
        private Button button5;
        private Label label8;
        private Label label7;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn suppIDGV;
        private DataGridViewTextBoxColumn CompanyGV;
        private DataGridViewTextBoxColumn personGV;
        private DataGridViewTextBoxColumn PhoneGV;
        private DataGridViewTextBoxColumn addressGV;
        private DataGridViewTextBoxColumn ntnGV;
        private DataGridViewTextBoxColumn statusGV;
    }
}