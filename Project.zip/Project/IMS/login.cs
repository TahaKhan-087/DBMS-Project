﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class login : Sample
    {
        public login()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (usernameTxt.Text == "") { NameErrorLabel.Visible = true; } else { NameErrorLabel.Visible = false; }
            if (passTxt.Text == "") { passErrorLabel.Visible = true; } else { passErrorLabel.Visible = false; }
            if (NameErrorLabel.Visible || passErrorLabel.Visible)
            {
                MainClass.ShowMsg("Fields with * are mandatory", "Stop", "Error");
            }
            else
            {
                if (usernameTxt.Text != "" && passTxt.Text != "")
                    if (Retrieval.getUserDetails(usernameTxt.Text, passTxt.Text))
                    {
                        Homescreen hm = new Homescreen();
                        MainClass.showWindow(hm, this, MDI.ActiveForm);
                    }
                    else
                    {

                    }
            }
        }

        private void usernameTxt_TextChanged(object sender, EventArgs e)
        {
            if (usernameTxt.Text == "") { NameErrorLabel.Visible = true; } else { NameErrorLabel.Visible = false; }
        }

        private void passTxt_TextChanged(object sender, EventArgs e)
        {
            if (passTxt.Text == "") { passErrorLabel.Visible = true; } else { passErrorLabel.Visible = false; }
        }
    }
}
