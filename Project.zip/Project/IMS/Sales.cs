﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMS
{
    public partial class Sales : Sample2
    {
        public Sales()
        {
            InitializeComponent();
        }
        int productID;
        string[] prodARR = new string[4];
        Retrieval r = new Retrieval();
        float gross;
        private void barcodeTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void barcodeTxt_Validating(object sender, CancelEventArgs e)
        {
            float total;
            if (barcodeTxt.Text != "")
            {
                prodARR = r.getProductsWRTBarcode(barcodeTxt.Text);
                productID = Convert.ToInt32(prodARR[0]);
                if (dataGridView1.Rows.Count != 0)
                {
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (row.Cells["proIDGV"].Value.ToString() == productID.ToString())
                        {

                            int quan = Convert.ToInt32(row.Cells["quantGV"].Value.ToString());
                            quan += 1;
                            total = Convert.ToSingle(row.Cells["pupGV"].Value.ToString()) * quan;
                            row.Cells["quantGV"].Value = quan;
                            row.Cells["TotGV"].Value = total;
                            gross += total;
                            grossLabel.Text = gross.ToString();
                            total = 0;
                            quan = 0;
                            barcodeTxt.Focus();
                        }
                        else
                        {
                            dataGridView1.Rows.Add(productID, prodARR[1], 1, prodARR[2], prodARR[2]);
                            gross += Convert.ToSingle(row.Cells["TotGV"].Value.ToString());
                            grossLabel.Text = gross.ToString();
                            barcodeTxt.Focus();
                        }
                    }
                }
                else
                {
                    dataGridView1.Rows.Add(productID, prodARR[1], 1, prodARR[2], prodARR[2]);
                    gross += Convert.ToSingle(prodARR[2]);
                    grossLabel.Text = gross.ToString();
                    barcodeTxt.Focus();
                }
                //productTxt.Text = prodARR[1];
                //pupTxt.Text = prodARR[2];
                //string barco = prodARR[3];
                //productTxt.Enabled = false;
                //pupTxt.Enabled = false;
                //if (barco != null)
                //{
                //    quanTxt.Focus();
                //}
            }
            else
            {
                productID = 0;
                //productTxt.Text = "";
                //pupTxt.Text = "";
                Array.Clear(prodARR, 0, prodARR.Length);
            }

            if (barcodeTxt.Text != "")
            {
                prodARR = r.getProductsWRTBarcode(barcodeTxt.Text);
                dataGridView1.Rows.Add(Convert.ToInt32(prodARR[0]), Convert.ToSingle(prodARR[1]), prodARR[2]);
                foreach(DataGridViewRow row in dataGridView1.Rows)
                {
                    //gross += Convert.ToSingle(items.Cells["TotGV"].Value.ToString());
                }
                grossLabel.Text = gross.ToString() ;
                gross = 0;
            }
        }
    }
}
