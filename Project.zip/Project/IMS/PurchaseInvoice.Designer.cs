﻿namespace IMS
{
    partial class PurchaseInvoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            label2 = new Label();
            SupplierDD = new ComboBox();
            label3 = new Label();
            productTxt = new TextBox();
            quanTxt = new TextBox();
            label4 = new Label();
            barcodeTxt = new TextBox();
            label5 = new Label();
            pupTxt = new TextBox();
            label6 = new Label();
            dataGridView1 = new DataGridView();
            proIDGV = new DataGridViewTextBoxColumn();
            proGV = new DataGridViewTextBoxColumn();
            quantityGV = new DataGridViewTextBoxColumn();
            pupGV = new DataGridViewTextBoxColumn();
            TotGV = new DataGridViewTextBoxColumn();
            deleteGV = new DataGridViewButtonColumn();
            cartBtn = new Button();
            label7 = new Label();
            totlabel = new Label();
            panel5 = new Panel();
            tableLayoutPanel2 = new TableLayoutPanel();
            grossLabel = new Label();
            label9 = new Label();
            suppErrorLabel = new Label();
            barErrorLabel = new Label();
            quanErrorLabel = new Label();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel5.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.Location = new Point(0, 0);
            panel3.Size = new Size(663, 46);
            // 
            // panel4
            // 
            panel4.Location = new Point(0, 0);
            // 
            // SearchTxtBox
            // 
            SearchTxtBox.Size = new Size(101, 25);
            // 
            // BackBtn
            // 
            BackBtn.FlatAppearance.BorderSize = 2;
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(suppErrorLabel);
            LeftPanel.Controls.Add(totlabel);
            LeftPanel.Controls.Add(label9);
            LeftPanel.Controls.Add(cartBtn);
            LeftPanel.Controls.Add(pupTxt);
            LeftPanel.Controls.Add(barcodeTxt);
            LeftPanel.Controls.Add(quanTxt);
            LeftPanel.Controls.Add(productTxt);
            LeftPanel.Controls.Add(SupplierDD);
            LeftPanel.Controls.Add(label2);
            LeftPanel.Controls.Add(label5);
            LeftPanel.Controls.Add(label3);
            LeftPanel.Controls.Add(label6);
            LeftPanel.Controls.Add(label4);
            LeftPanel.Controls.Add(barErrorLabel);
            LeftPanel.Controls.Add(quanErrorLabel);
            LeftPanel.Size = new Size(250, 541);
            LeftPanel.Controls.SetChildIndex(panel4, 0);
            LeftPanel.Controls.SetChildIndex(quanErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(barErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(label4, 0);
            LeftPanel.Controls.SetChildIndex(label6, 0);
            LeftPanel.Controls.SetChildIndex(label3, 0);
            LeftPanel.Controls.SetChildIndex(label5, 0);
            LeftPanel.Controls.SetChildIndex(panel1, 0);
            LeftPanel.Controls.SetChildIndex(label2, 0);
            LeftPanel.Controls.SetChildIndex(SupplierDD, 0);
            LeftPanel.Controls.SetChildIndex(productTxt, 0);
            LeftPanel.Controls.SetChildIndex(quanTxt, 0);
            LeftPanel.Controls.SetChildIndex(barcodeTxt, 0);
            LeftPanel.Controls.SetChildIndex(pupTxt, 0);
            LeftPanel.Controls.SetChildIndex(cartBtn, 0);
            LeftPanel.Controls.SetChildIndex(label9, 0);
            LeftPanel.Controls.SetChildIndex(totlabel, 0);
            LeftPanel.Controls.SetChildIndex(suppErrorLabel, 0);
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(panel5);
            RightPanel.Controls.Add(dataGridView1);
            RightPanel.Size = new Size(663, 541);
            RightPanel.Controls.SetChildIndex(panel3, 0);
            RightPanel.Controls.SetChildIndex(panel2, 0);
            RightPanel.Controls.SetChildIndex(dataGridView1, 0);
            RightPanel.Controls.SetChildIndex(panel5, 0);
            // 
            // panel1
            // 
            panel1.Location = new Point(0, 46);
            // 
            // panel2
            // 
            panel2.Location = new Point(0, 46);
            panel2.Size = new Size(663, 85);
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 131);
            label2.Name = "label2";
            label2.Size = new Size(108, 20);
            label2.TabIndex = 2;
            label2.Text = "Select Supplier";
            // 
            // SupplierDD
            // 
            SupplierDD.FormattingEnabled = true;
            SupplierDD.Location = new Point(12, 154);
            SupplierDD.Name = "SupplierDD";
            SupplierDD.Size = new Size(232, 28);
            SupplierDD.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 228);
            label3.Name = "label3";
            label3.Size = new Size(60, 20);
            label3.TabIndex = 4;
            label3.Text = "Product";
            // 
            // productTxt
            // 
            productTxt.Location = new Point(12, 248);
            productTxt.Name = "productTxt";
            productTxt.Size = new Size(232, 27);
            productTxt.TabIndex = 5;
            // 
            // quanTxt
            // 
            quanTxt.Location = new Point(12, 338);
            quanTxt.Name = "quanTxt";
            quanTxt.Size = new Size(232, 27);
            quanTxt.TabIndex = 7;
            quanTxt.TextChanged += quanTxt_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 317);
            label4.Name = "label4";
            label4.Size = new Size(109, 20);
            label4.TabIndex = 6;
            label4.Text = "Select Quantity";
            // 
            // barcodeTxt
            // 
            barcodeTxt.Location = new Point(12, 202);
            barcodeTxt.Name = "barcodeTxt";
            barcodeTxt.Size = new Size(232, 27);
            barcodeTxt.TabIndex = 9;
            barcodeTxt.TextChanged += barcodeTxt_TextChanged;
            barcodeTxt.Validated += barcodeTxt_Validated;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(16, 181);
            label5.Name = "label5";
            label5.Size = new Size(64, 20);
            label5.TabIndex = 8;
            label5.Text = "Barcode";
            // 
            // pupTxt
            // 
            pupTxt.Location = new Point(12, 293);
            pupTxt.Name = "pupTxt";
            pupTxt.Size = new Size(232, 27);
            pupTxt.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(16, 273);
            label6.Name = "label6";
            label6.Size = new Size(96, 20);
            label6.TabIndex = 10;
            label6.Text = "Per Unit Price";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { proIDGV, proGV, quantityGV, pupGV, TotGV, deleteGV });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.ControlDark;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.Dock = DockStyle.Top;
            dataGridView1.Location = new Point(0, 131);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(663, 331);
            dataGridView1.TabIndex = 5;
            dataGridView1.CellClick += dataGridView1_CellClick;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // proIDGV
            // 
            proIDGV.HeaderText = "proID";
            proIDGV.MinimumWidth = 6;
            proIDGV.Name = "proIDGV";
            proIDGV.ReadOnly = true;
            proIDGV.Visible = false;
            // 
            // proGV
            // 
            proGV.HeaderText = "Product";
            proGV.MinimumWidth = 6;
            proGV.Name = "proGV";
            proGV.ReadOnly = true;
            // 
            // quantityGV
            // 
            quantityGV.HeaderText = "Quantity";
            quantityGV.MinimumWidth = 6;
            quantityGV.Name = "quantityGV";
            quantityGV.ReadOnly = true;
            // 
            // pupGV
            // 
            pupGV.HeaderText = "per Unit Price";
            pupGV.MinimumWidth = 6;
            pupGV.Name = "pupGV";
            pupGV.ReadOnly = true;
            // 
            // TotGV
            // 
            TotGV.HeaderText = "Total Amount";
            TotGV.MinimumWidth = 6;
            TotGV.Name = "TotGV";
            TotGV.ReadOnly = true;
            // 
            // deleteGV
            // 
            deleteGV.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            deleteGV.HeaderText = "Action";
            deleteGV.MinimumWidth = 6;
            deleteGV.Name = "deleteGV";
            deleteGV.ReadOnly = true;
            deleteGV.Text = "DELETE";
            deleteGV.UseColumnTextForButtonValue = true;
            // 
            // cartBtn
            // 
            cartBtn.Cursor = Cursors.Hand;
            cartBtn.FlatAppearance.BorderSize = 2;
            cartBtn.FlatStyle = FlatStyle.Flat;
            cartBtn.Location = new Point(12, 368);
            cartBtn.Name = "cartBtn";
            cartBtn.Size = new Size(232, 29);
            cartBtn.TabIndex = 12;
            cartBtn.Text = "ADD TO CART";
            cartBtn.UseVisualStyleBackColor = true;
            cartBtn.Click += cartBtn_Click;
            // 
            // label7
            // 
            label7.Dock = DockStyle.Fill;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(3, 0);
            label7.Name = "label7";
            label7.Size = new Size(441, 79);
            label7.TabIndex = 13;
            label7.Text = "Gross Total:";
            label7.TextAlign = ContentAlignment.MiddleRight;
            // 
            // totlabel
            // 
            totlabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            totlabel.ImageAlign = ContentAlignment.MiddleLeft;
            totlabel.Location = new Point(107, 420);
            totlabel.Name = "totlabel";
            totlabel.Size = new Size(157, 62);
            totlabel.TabIndex = 14;
            totlabel.Text = "0.00";
            totlabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // panel5
            // 
            panel5.Controls.Add(tableLayoutPanel2);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(0, 462);
            panel5.Name = "panel5";
            panel5.Size = new Size(663, 79);
            panel5.TabIndex = 6;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 67.4208145F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32.5791855F));
            tableLayoutPanel2.Controls.Add(label7, 0, 0);
            tableLayoutPanel2.Controls.Add(grossLabel, 1, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(0, 0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(663, 79);
            tableLayoutPanel2.TabIndex = 15;
            // 
            // grossLabel
            // 
            grossLabel.AutoSize = true;
            grossLabel.Dock = DockStyle.Fill;
            grossLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            grossLabel.Location = new Point(450, 0);
            grossLabel.Name = "grossLabel";
            grossLabel.Size = new Size(210, 79);
            grossLabel.TabIndex = 16;
            grossLabel.Text = "0.00";
            grossLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(12, 400);
            label9.Name = "label9";
            label9.Size = new Size(102, 20);
            label9.TabIndex = 15;
            label9.Text = "Total Amount:";
            // 
            // suppErrorLabel
            // 
            suppErrorLabel.AutoSize = true;
            suppErrorLabel.Location = new Point(126, 134);
            suppErrorLabel.Name = "suppErrorLabel";
            suppErrorLabel.Size = new Size(15, 20);
            suppErrorLabel.TabIndex = 17;
            suppErrorLabel.Text = "*";
            suppErrorLabel.Visible = false;
            // 
            // barErrorLabel
            // 
            barErrorLabel.AutoSize = true;
            barErrorLabel.Location = new Point(82, 181);
            barErrorLabel.Name = "barErrorLabel";
            barErrorLabel.Size = new Size(15, 20);
            barErrorLabel.TabIndex = 18;
            barErrorLabel.Text = "*";
            barErrorLabel.Visible = false;
            // 
            // quanErrorLabel
            // 
            quanErrorLabel.AutoSize = true;
            quanErrorLabel.Location = new Point(126, 317);
            quanErrorLabel.Name = "quanErrorLabel";
            quanErrorLabel.Size = new Size(15, 20);
            quanErrorLabel.TabIndex = 19;
            quanErrorLabel.Text = "*";
            quanErrorLabel.Visible = false;
            // 
            // PurchaseInvoice
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(913, 541);
            Name = "PurchaseInvoice";
            Text = "PurchaseInvoice";
            Load += PurchaseInvoice_Load;
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel5.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label2;
        private ComboBox SupplierDD;
        private TextBox productTxt;
        private Label label3;
        private TextBox quanTxt;
        private Label label4;
        private TextBox pupTxt;
        private Label label6;
        private TextBox barcodeTxt;
        private Label label5;
        private Button cartBtn;
        private DataGridView dataGridView1;
        private Label totlabel;
        private Label label7;
        private Panel panel5;
        private Label grossLabel;
        private Label label9;
        private TableLayoutPanel tableLayoutPanel2;
        private Label suppErrorLabel;
        private Label barErrorLabel;
        private Label quanErrorLabel;
        private DataGridViewTextBoxColumn proIDGV;
        private DataGridViewTextBoxColumn proGV;
        private DataGridViewTextBoxColumn quantityGV;
        private DataGridViewTextBoxColumn pupGV;
        private DataGridViewTextBoxColumn TotGV;
        private DataGridViewButtonColumn deleteGV;
    }
}