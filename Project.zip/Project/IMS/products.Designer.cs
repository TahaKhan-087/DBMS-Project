﻿namespace IMS
{
    partial class products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            label3 = new Label();
            proTxt = new TextBox();
            proErrorLabel = new Label();
            barcodeErrorLable = new Label();
            barcodeTxt = new TextBox();
            label5 = new Label();
            label7 = new Label();
            expiryPicker = new DateTimePicker();
            expiryErrorLable = new Label();
            priceErrorLable = new Label();
            priceTxt = new TextBox();
            label9 = new Label();
            label4 = new Label();
            CategoryDD = new ComboBox();
            catErrorLabel = new Label();
            dataGridView1 = new DataGridView();
            proIDGV = new DataGridViewTextBoxColumn();
            proGV = new DataGridViewTextBoxColumn();
            barcodeGV = new DataGridViewTextBoxColumn();
            expiryGV = new DataGridViewTextBoxColumn();
            priceGV = new DataGridViewTextBoxColumn();
            catIDGV = new DataGridViewTextBoxColumn();
            catGV = new DataGridViewTextBoxColumn();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(catErrorLabel);
            LeftPanel.Controls.Add(CategoryDD);
            LeftPanel.Controls.Add(label4);
            LeftPanel.Controls.Add(priceErrorLable);
            LeftPanel.Controls.Add(priceTxt);
            LeftPanel.Controls.Add(label9);
            LeftPanel.Controls.Add(expiryErrorLable);
            LeftPanel.Controls.Add(expiryPicker);
            LeftPanel.Controls.Add(label7);
            LeftPanel.Controls.Add(barcodeErrorLable);
            LeftPanel.Controls.Add(barcodeTxt);
            LeftPanel.Controls.Add(label5);
            LeftPanel.Controls.Add(proErrorLabel);
            LeftPanel.Controls.Add(proTxt);
            LeftPanel.Controls.Add(label3);
            LeftPanel.Controls.SetChildIndex(panel1, 0);
            LeftPanel.Controls.SetChildIndex(label3, 0);
            LeftPanel.Controls.SetChildIndex(proTxt, 0);
            LeftPanel.Controls.SetChildIndex(proErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(label5, 0);
            LeftPanel.Controls.SetChildIndex(barcodeTxt, 0);
            LeftPanel.Controls.SetChildIndex(barcodeErrorLable, 0);
            LeftPanel.Controls.SetChildIndex(label7, 0);
            LeftPanel.Controls.SetChildIndex(expiryPicker, 0);
            LeftPanel.Controls.SetChildIndex(expiryErrorLable, 0);
            LeftPanel.Controls.SetChildIndex(label9, 0);
            LeftPanel.Controls.SetChildIndex(priceTxt, 0);
            LeftPanel.Controls.SetChildIndex(priceErrorLable, 0);
            LeftPanel.Controls.SetChildIndex(label4, 0);
            LeftPanel.Controls.SetChildIndex(CategoryDD, 0);
            LeftPanel.Controls.SetChildIndex(catErrorLabel, 0);
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(dataGridView1);
            RightPanel.Controls.SetChildIndex(panel2, 0);
            RightPanel.Controls.SetChildIndex(dataGridView1, 0);
            // 
            // panel1
            // 
            panel1.Location = new Point(0, 46);
            // 
            // panel2
            // 
            panel2.Location = new Point(0, 46);
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 135);
            label3.Name = "label3";
            label3.Size = new Size(104, 20);
            label3.TabIndex = 2;
            label3.Text = "Product Name";
            // 
            // proTxt
            // 
            proTxt.Location = new Point(12, 158);
            proTxt.Name = "proTxt";
            proTxt.Size = new Size(232, 27);
            proTxt.TabIndex = 3;
            // 
            // proErrorLabel
            // 
            proErrorLabel.AutoSize = true;
            proErrorLabel.Location = new Point(112, 135);
            proErrorLabel.Name = "proErrorLabel";
            proErrorLabel.Size = new Size(15, 20);
            proErrorLabel.TabIndex = 13;
            proErrorLabel.Text = "*";
            proErrorLabel.Visible = false;
            // 
            // barcodeErrorLable
            // 
            barcodeErrorLable.AutoSize = true;
            barcodeErrorLable.Location = new Point(79, 189);
            barcodeErrorLable.Name = "barcodeErrorLable";
            barcodeErrorLable.Size = new Size(15, 20);
            barcodeErrorLable.TabIndex = 16;
            barcodeErrorLable.Text = "*";
            barcodeErrorLable.Visible = false;
            // 
            // barcodeTxt
            // 
            barcodeTxt.Location = new Point(12, 212);
            barcodeTxt.Name = "barcodeTxt";
            barcodeTxt.Size = new Size(232, 27);
            barcodeTxt.TabIndex = 15;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 189);
            label5.Name = "label5";
            label5.Size = new Size(64, 20);
            label5.TabIndex = 14;
            label5.Text = "Barcode";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 242);
            label7.Name = "label7";
            label7.Size = new Size(85, 20);
            label7.TabIndex = 17;
            label7.Text = "Expiry Date";
            // 
            // expiryPicker
            // 
            expiryPicker.CustomFormat = "dd-MMM-yyy";
            expiryPicker.Format = DateTimePickerFormat.Custom;
            expiryPicker.Location = new Point(12, 267);
            expiryPicker.Name = "expiryPicker";
            expiryPicker.Size = new Size(232, 27);
            expiryPicker.TabIndex = 18;
            // 
            // expiryErrorLable
            // 
            expiryErrorLable.AutoSize = true;
            expiryErrorLable.Location = new Point(103, 242);
            expiryErrorLable.Name = "expiryErrorLable";
            expiryErrorLable.Size = new Size(15, 20);
            expiryErrorLable.TabIndex = 19;
            expiryErrorLable.Text = "*";
            expiryErrorLable.Visible = false;
            // 
            // priceErrorLable
            // 
            priceErrorLable.AutoSize = true;
            priceErrorLable.Location = new Point(59, 297);
            priceErrorLable.Name = "priceErrorLable";
            priceErrorLable.Size = new Size(15, 20);
            priceErrorLable.TabIndex = 22;
            priceErrorLable.Text = "*";
            priceErrorLable.Visible = false;
            // 
            // priceTxt
            // 
            priceTxt.Location = new Point(12, 320);
            priceTxt.Name = "priceTxt";
            priceTxt.Size = new Size(232, 27);
            priceTxt.TabIndex = 21;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(12, 297);
            label9.Name = "label9";
            label9.Size = new Size(41, 20);
            label9.TabIndex = 20;
            label9.Text = "Price";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 350);
            label4.Name = "label4";
            label4.Size = new Size(69, 20);
            label4.TabIndex = 23;
            label4.Text = "Category";
            // 
            // CategoryDD
            // 
            CategoryDD.DropDownStyle = ComboBoxStyle.DropDownList;
            CategoryDD.FormattingEnabled = true;
            CategoryDD.Location = new Point(12, 373);
            CategoryDD.Name = "CategoryDD";
            CategoryDD.Size = new Size(232, 28);
            CategoryDD.TabIndex = 24;
            // 
            // catErrorLabel
            // 
            catErrorLabel.AutoSize = true;
            catErrorLabel.Location = new Point(79, 350);
            catErrorLabel.Name = "catErrorLabel";
            catErrorLabel.Size = new Size(15, 20);
            catErrorLabel.TabIndex = 25;
            catErrorLabel.Text = "*";
            catErrorLabel.Visible = false;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { proIDGV, proGV, barcodeGV, expiryGV, priceGV, catIDGV, catGV });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = SystemColors.Window;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.ControlDark;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.Location = new Point(0, 131);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(550, 319);
            dataGridView1.TabIndex = 4;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // proIDGV
            // 
            proIDGV.HeaderText = "proID";
            proIDGV.MinimumWidth = 6;
            proIDGV.Name = "proIDGV";
            proIDGV.ReadOnly = true;
            proIDGV.Visible = false;
            // 
            // proGV
            // 
            proGV.HeaderText = "Product";
            proGV.MinimumWidth = 6;
            proGV.Name = "proGV";
            proGV.ReadOnly = true;
            // 
            // barcodeGV
            // 
            barcodeGV.HeaderText = "Barcode";
            barcodeGV.MinimumWidth = 6;
            barcodeGV.Name = "barcodeGV";
            barcodeGV.ReadOnly = true;
            // 
            // expiryGV
            // 
            expiryGV.HeaderText = "Expiry Date";
            expiryGV.MinimumWidth = 6;
            expiryGV.Name = "expiryGV";
            expiryGV.ReadOnly = true;
            // 
            // priceGV
            // 
            dataGridViewCellStyle2.Format = "C2";
            dataGridViewCellStyle2.NullValue = null;
            priceGV.DefaultCellStyle = dataGridViewCellStyle2;
            priceGV.HeaderText = "Price";
            priceGV.MinimumWidth = 6;
            priceGV.Name = "priceGV";
            priceGV.ReadOnly = true;
            // 
            // catIDGV
            // 
            catIDGV.HeaderText = "CatIDGV";
            catIDGV.MinimumWidth = 6;
            catIDGV.Name = "catIDGV";
            catIDGV.ReadOnly = true;
            catIDGV.Visible = false;
            // 
            // catGV
            // 
            catGV.HeaderText = "Category";
            catGV.MinimumWidth = 6;
            catGV.Name = "catGV";
            catGV.ReadOnly = true;
            // 
            // products
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "products";
            Text = "products";
            Load += products_Load;
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TextBox proTxt;
        private Label label3;
        private TextBox textBox2;
        private Label label7;
        private Label barcodeErrorLable;
        private TextBox barcodeTxt;
        private Label label5;
        private Label proErrorLabel;
        private Label priceErrorLable;
        private TextBox priceTxt;
        private Label label9;
        private Label expiryErrorLable;
        private DateTimePicker expiryPicker;
        private Label catErrorLabel;
        private ComboBox CategoryDD;
        private Label label4;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn proIDGV;
        private DataGridViewTextBoxColumn proGV;
        private DataGridViewTextBoxColumn barcodeGV;
        private DataGridViewTextBoxColumn expiryGV;
        private DataGridViewTextBoxColumn priceGV;
        private DataGridViewTextBoxColumn catIDGV;
        private DataGridViewTextBoxColumn catGV;
    }
}