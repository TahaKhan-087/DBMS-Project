﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace IMS
{
    public partial class products : Sample2
    {
        int edit = 0; // This zero is an indication to the save operation and one is an indication to the Update operation
        int proID;
        public products()
        {
            InitializeComponent();
        }
        Retrieval r = new Retrieval();

        private void products_Load(object sender, EventArgs e)
        {
            MainClass.disable_reset(LeftPanel);
        }

        public override void addBtn_Click(object sender, EventArgs e)
        {
            MainClass.enable_reset(LeftPanel);
            edit = 0;
            r.getList("st_getCategoriesList", CategoryDD, "Category", "ID");
        }

        public override void EditBtn_Click(object sender, EventArgs e)
        {
            edit = 1;
            MainClass.enable(LeftPanel);
        }

        public override void saveBtn_Click(object sender, EventArgs e)
        {
            if (proTxt.Text == "") { proErrorLabel.Visible = true; } else { proErrorLabel.Visible = false; }
            if (barcodeTxt.Text == "") { barcodeErrorLable.Visible = true; } else { barcodeErrorLable.Visible = false; }
            if (expiryPicker.Value.Date < DateTime.Now.Date) { expiryErrorLable.Visible = true; expiryErrorLable.Text = "Invalid date"; } else { expiryErrorLable.Visible = false; }
            if (priceTxt.Text == "") { priceErrorLable.Visible = true; } else { priceErrorLable.Visible = false; }
            if (CategoryDD.SelectedIndex == -1 || CategoryDD.SelectedIndex == 0) { catErrorLabel.Visible = true; } else { catErrorLabel.Visible = false; }

            if (proErrorLabel.Visible || barcodeErrorLable.Visible || expiryErrorLable.Visible || priceErrorLable.Visible || catErrorLabel.Visible)
            {
                MainClass.ShowMsg("Fields with * are mandatory", "Stop", "Error"); //Error is the type of msg
            }

            else
            {

                if (edit == 0) //Code for save operation
                {
                    insertion i = new insertion();
                    i.insertProduct(proTxt.Text, barcodeTxt.Text, Convert.ToSingle(priceTxt.Text), expiryPicker.Value, Convert.ToInt32(CategoryDD.SelectedValue));
                    r.showProducts(dataGridView1, proIDGV, proGV, expiryGV, catGV, priceGV, barcodeGV, catIDGV);
                    MainClass.disable_reset(LeftPanel);
                }

                else if (edit == 1) //Code for  Update operation
                {
                    DialogResult dr = MessageBox.Show("Are you sure, you want to update record?", "Question...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr == DialogResult.Yes)
                    {
                        Updation u = new Updation();
                        u.updateProduct(proID, proTxt.Text, barcodeTxt.Text, Convert.ToSingle(priceTxt.Text), expiryPicker.Value, Convert.ToInt32(CategoryDD.SelectedValue));
                        r.showProducts(dataGridView1, proIDGV, proGV, expiryGV, catGV, priceGV, barcodeGV, catIDGV);
                        MainClass.disable_reset(LeftPanel);
                    }
                }
            }
        }

        public override void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (edit == 1)
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to delete record?", "Question...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    Deletion d = new Deletion();
                    d.Delete(proID, "s_productDelete", "@proID");
                    r.showProducts(dataGridView1, proIDGV, proGV, expiryGV, catGV, priceGV, barcodeGV, catIDGV);
                }
            }
        }

        public override void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public override void viewBtn_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && e.ColumnIndex!=-1)
            {
                edit = 1;
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                proID = Convert.ToInt32(row.Cells["proIDGV"].Value.ToString());
                proTxt.Text = row.Cells["proGV"].Value.ToString();
                priceTxt.Text = row.Cells["priceGV"].Value.ToString();
                barcodeTxt.Text = row.Cells["barcodeGV"].Value.ToString();
                expiryPicker.Value = Convert.ToDateTime( row.Cells["expiryGV"].Value.ToString());
                CategoryDD.SelectedItem = row.Cells["catGV"].Value.ToString();
                MainClass.disable(LeftPanel);
            }
        }
    }
}
