﻿namespace IMS
{
    partial class PurchaseInvoiceDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            label2 = new Label();
            datePicker = new DateTimePicker();
            label3 = new Label();
            purchaseDD = new ComboBox();
            dataGridView1 = new DataGridView();
            tableLayoutPanel2 = new TableLayoutPanel();
            grossLabel = new Label();
            label7 = new Label();
            proIDGV = new DataGridViewTextBoxColumn();
            proGV = new DataGridViewTextBoxColumn();
            quantityGV = new DataGridViewTextBoxColumn();
            pupGV = new DataGridViewTextBoxColumn();
            TotGV = new DataGridViewTextBoxColumn();
            deleteGV = new DataGridViewButtonColumn();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tableLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(purchaseDD);
            LeftPanel.Controls.Add(label3);
            LeftPanel.Controls.Add(datePicker);
            LeftPanel.Controls.Add(label2);
            LeftPanel.Paint += LeftPanel_Paint;
            LeftPanel.Controls.SetChildIndex(panel1, 0);
            LeftPanel.Controls.SetChildIndex(label2, 0);
            LeftPanel.Controls.SetChildIndex(datePicker, 0);
            LeftPanel.Controls.SetChildIndex(label3, 0);
            LeftPanel.Controls.SetChildIndex(purchaseDD, 0);
            // 
            // RightPanel
            // 
            RightPanel.Controls.Add(tableLayoutPanel2);
            RightPanel.Controls.Add(dataGridView1);
            RightPanel.Controls.SetChildIndex(panel2, 0);
            RightPanel.Controls.SetChildIndex(dataGridView1, 0);
            RightPanel.Controls.SetChildIndex(tableLayoutPanel2, 0);
            // 
            // panel1
            // 
            panel1.Location = new Point(0, 46);
            // 
            // panel2
            // 
            panel2.Location = new Point(0, 46);
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(3, 157);
            label2.Name = "label2";
            label2.Size = new Size(88, 20);
            label2.TabIndex = 2;
            label2.Text = "Select Date:";
            // 
            // datePicker
            // 
            datePicker.CustomFormat = "MMM-yyyy";
            datePicker.Format = DateTimePickerFormat.Custom;
            datePicker.Location = new Point(3, 180);
            datePicker.Name = "datePicker";
            datePicker.ShowUpDown = true;
            datePicker.Size = new Size(241, 27);
            datePicker.TabIndex = 3;
            datePicker.ValueChanged += datePicker_ValueChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(3, 219);
            label3.Name = "label3";
            label3.Size = new Size(165, 20);
            label3.TabIndex = 4;
            label3.Text = "Select Purchase Invoice:";
            // 
            // purchaseDD
            // 
            purchaseDD.DropDownStyle = ComboBoxStyle.DropDownList;
            purchaseDD.FormattingEnabled = true;
            purchaseDD.Location = new Point(3, 242);
            purchaseDD.Name = "purchaseDD";
            purchaseDD.Size = new Size(241, 28);
            purchaseDD.TabIndex = 5;
            purchaseDD.SelectedIndexChanged += purchaseDD_SelectedIndexChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { proIDGV, proGV, quantityGV, pupGV, TotGV, deleteGV });
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.Window;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.ControlDark;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            dataGridView1.Dock = DockStyle.Top;
            dataGridView1.Location = new Point(0, 131);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(550, 227);
            dataGridView1.TabIndex = 6;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66.36364F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.636364F));
            tableLayoutPanel2.Controls.Add(grossLabel, 0, 0);
            tableLayoutPanel2.Controls.Add(label7, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(0, 358);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(550, 92);
            tableLayoutPanel2.TabIndex = 7;
            // 
            // grossLabel
            // 
            grossLabel.AutoSize = true;
            grossLabel.Dock = DockStyle.Fill;
            grossLabel.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            grossLabel.Location = new Point(368, 0);
            grossLabel.Name = "grossLabel";
            grossLabel.Size = new Size(179, 92);
            grossLabel.TabIndex = 17;
            grossLabel.Text = "0.00";
            grossLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            label7.Dock = DockStyle.Fill;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(3, 0);
            label7.Name = "label7";
            label7.Size = new Size(359, 92);
            label7.TabIndex = 14;
            label7.Text = "Gross Total:";
            label7.TextAlign = ContentAlignment.MiddleRight;
            // 
            // proIDGV
            // 
            proIDGV.HeaderText = "proID";
            proIDGV.MinimumWidth = 6;
            proIDGV.Name = "proIDGV";
            proIDGV.ReadOnly = true;
            proIDGV.Visible = false;
            // 
            // proGV
            // 
            proGV.HeaderText = "Product";
            proGV.MinimumWidth = 6;
            proGV.Name = "proGV";
            proGV.ReadOnly = true;
            // 
            // quantityGV
            // 
            quantityGV.HeaderText = "Quantity";
            quantityGV.MinimumWidth = 6;
            quantityGV.Name = "quantityGV";
            quantityGV.ReadOnly = true;
            // 
            // pupGV
            // 
            dataGridViewCellStyle2.Format = "C2";
            dataGridViewCellStyle2.NullValue = null;
            pupGV.DefaultCellStyle = dataGridViewCellStyle2;
            pupGV.HeaderText = "per Unit Price";
            pupGV.MinimumWidth = 6;
            pupGV.Name = "pupGV";
            pupGV.ReadOnly = true;
            // 
            // TotGV
            // 
            dataGridViewCellStyle3.Format = "C2";
            dataGridViewCellStyle3.NullValue = null;
            TotGV.DefaultCellStyle = dataGridViewCellStyle3;
            TotGV.HeaderText = "Total Amount";
            TotGV.MinimumWidth = 6;
            TotGV.Name = "TotGV";
            TotGV.ReadOnly = true;
            // 
            // deleteGV
            // 
            deleteGV.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            deleteGV.HeaderText = "Action";
            deleteGV.MinimumWidth = 6;
            deleteGV.Name = "deleteGV";
            deleteGV.ReadOnly = true;
            deleteGV.Text = "DELETE";
            deleteGV.UseColumnTextForButtonValue = true;
            // 
            // PurchaseInvoiceDetails
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "PurchaseInvoiceDetails";
            Text = "Purchase Invoice Details";
            Load += PurchaseInvoiceDetails_Load;
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DateTimePicker datePicker;
        private Label label2;
        private ComboBox purchaseDD;
        private Label label3;
        private DataGridView dataGridView1;
        private TableLayoutPanel tableLayoutPanel2;
        private Label label7;
        private Label grossLabel;
        private DataGridViewTextBoxColumn proIDGV;
        private DataGridViewTextBoxColumn proGV;
        private DataGridViewTextBoxColumn quantityGV;
        private DataGridViewTextBoxColumn pupGV;
        private DataGridViewTextBoxColumn TotGV;
        private DataGridViewButtonColumn deleteGV;
    }
}