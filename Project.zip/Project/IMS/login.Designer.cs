﻿namespace IMS
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            usernameTxt = new TextBox();
            label3 = new Label();
            label4 = new Label();
            passTxt = new TextBox();
            LoginBtn = new Button();
            NameErrorLabel = new Label();
            passErrorLabel = new Label();
            LeftPanel.SuspendLayout();
            RightPanel.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // LeftPanel
            // 
            LeftPanel.Controls.Add(passErrorLabel);
            LeftPanel.Controls.Add(NameErrorLabel);
            LeftPanel.Controls.Add(LoginBtn);
            LeftPanel.Controls.Add(label4);
            LeftPanel.Controls.Add(passTxt);
            LeftPanel.Controls.Add(label3);
            LeftPanel.Controls.Add(usernameTxt);
            LeftPanel.Controls.SetChildIndex(panel1, 0);
            LeftPanel.Controls.SetChildIndex(usernameTxt, 0);
            LeftPanel.Controls.SetChildIndex(label3, 0);
            LeftPanel.Controls.SetChildIndex(passTxt, 0);
            LeftPanel.Controls.SetChildIndex(label4, 0);
            LeftPanel.Controls.SetChildIndex(LoginBtn, 0);
            LeftPanel.Controls.SetChildIndex(NameErrorLabel, 0);
            LeftPanel.Controls.SetChildIndex(passErrorLabel, 0);
            // 
            // usernameTxt
            // 
            usernameTxt.Location = new Point(12, 186);
            usernameTxt.MaxLength = 40;
            usernameTxt.Name = "usernameTxt";
            usernameTxt.Size = new Size(203, 27);
            usernameTxt.TabIndex = 2;
            usernameTxt.TextChanged += usernameTxt_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 149);
            label3.Name = "label3";
            label3.Size = new Size(75, 20);
            label3.TabIndex = 3;
            label3.Text = "Username";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 232);
            label4.Name = "label4";
            label4.Size = new Size(70, 20);
            label4.TabIndex = 5;
            label4.Text = "Password";
            // 
            // passTxt
            // 
            passTxt.Location = new Point(12, 269);
            passTxt.MaxLength = 40;
            passTxt.Name = "passTxt";
            passTxt.Size = new Size(203, 27);
            passTxt.TabIndex = 4;
            passTxt.UseSystemPasswordChar = true;
            passTxt.TextChanged += passTxt_TextChanged;
            // 
            // LoginBtn
            // 
            LoginBtn.FlatAppearance.BorderSize = 2;
            LoginBtn.FlatStyle = FlatStyle.Flat;
            LoginBtn.Location = new Point(12, 317);
            LoginBtn.Name = "LoginBtn";
            LoginBtn.Size = new Size(203, 36);
            LoginBtn.TabIndex = 6;
            LoginBtn.Text = "Login";
            LoginBtn.UseVisualStyleBackColor = true;
            LoginBtn.Click += LoginBtn_Click;
            // 
            // NameErrorLabel
            // 
            NameErrorLabel.AutoSize = true;
            NameErrorLabel.Location = new Point(86, 149);
            NameErrorLabel.Name = "NameErrorLabel";
            NameErrorLabel.Size = new Size(15, 20);
            NameErrorLabel.TabIndex = 13;
            NameErrorLabel.Text = "*";
            NameErrorLabel.Visible = false;
            // 
            // passErrorLabel
            // 
            passErrorLabel.AutoSize = true;
            passErrorLabel.Location = new Point(80, 232);
            passErrorLabel.Name = "passErrorLabel";
            passErrorLabel.Size = new Size(15, 20);
            passErrorLabel.TabIndex = 14;
            passErrorLabel.Text = "*";
            passErrorLabel.Visible = false;
            // 
            // login
            // 
            AcceptButton = LoginBtn;
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Name = "login";
            Text = "login";
            LeftPanel.ResumeLayout(false);
            LeftPanel.PerformLayout();
            RightPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Label label4;
        private TextBox passTxt;
        private Label label3;
        private TextBox usernameTxt;
        private Button LoginBtn;
        private Label passErrorLabel;
        private Label NameErrorLabel;
    }
}