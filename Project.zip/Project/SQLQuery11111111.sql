use imsDB
create table supplier
(
sup_id int not null identity primary key,
sup_company varchar(100) not null unique,
sup_contactPerson varchar(50) not null,
sup_phone varchar(15) not null,
sup_address nvarchar (100) not null,
sup_ntn varchar (25),
sup_status tinyint not null,
)