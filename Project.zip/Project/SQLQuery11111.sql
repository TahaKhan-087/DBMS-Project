use imsDB

create table products
(
pro_id int not null identity primary key,
pro_name varchar (50) not null,
pro_barcode nvarchar(50) not null,
pro_price money not null,
pro_expiry date,
pro_catID int not null foreign key references categories(cat_id)
)

create procedure st_productInsert
@name varchar(50) ,
@barcode nvarchar(100) ,
@price money ,
@expiry date,
@catID int
as
insert into products values (@name,@barcode,@price,@expiry,@catID)

create procedure st_productUpdate
@name varchar(50),
@barcode nvarchar(100) ,
@price money,
@expiry date,
@catID int,
@proID int
as
update products
set
pro_name =@name,
pro_expiry =@expiry,
pro_price =@price,
pro_catID= @catID,
pro_barcode =@barcode,
where
pro_id = @proID

create procedure s_productDelete
@proID int
as
delete from products where pro_id = @proID


CREATE PROCEDURE st_getProductsData
AS
BEGIN
    SELECT
        p.pro_id AS 'Product ID',
        p.pro_name AS 'Product',
        FORMAT(p.pro_expiry, 'dd-MMM-yyyy') AS 'Expiry',
        p.pro_price AS 'Price',
        p.pro_barcode AS 'Barcode',
        c.cat_name AS 'Category',
        c.cat_id AS 'Category ID'
    FROM products p
    INNER JOIN categories c ON c.cat_id = p.pro_catID;
END;
GO